// implemented by SQ on 06/28/2018
package structures;

public class DoublyCircularLinkedListImplementation<T extends Comparable<T>> implements
		DoublyCicularLinkedList<T> {
    
    /*
     * Precondition: nobody is attempting to mess up my code by adding null elements to the list?
     */
    
    // variable declarations --------------------
    private DLLNode<T> head;
    private DLLNode<T> current;
    private int size;
	
    // constructors --------------------
	public DoublyCircularLinkedListImplementation() {
	    this.head = null;
	    this.current = null;
	    this.size = 0;
	    return;
	}

	// helper functions --------------------
    /**
     * Creates the first element for the list.
     * Put into a function in accordance to DRY principle.
     * 
     * Precondition: list is empty, data is not null
     * 
     * @param data: element to be added to the list
     */
    private void createFirstElem(T data) {
        DLLNode<T> node = new DLLNode<T>(data);
        node.setBack(node);
        node.setForward(node);
        this.head = node;
        this.current = node;
        this.size ++;
        return;
    }
    
    /**
     * Removing the only element is the same as reinitializing the object, duh.
     */
    private void deleteOnlyElem() {
        this.head = null;
        this.current = null;
        this.size = 0;
        return;
    }
    
    /**
     * Removes the current node from the list. Points this.current forward if current == node
     * 
     * Precondition: node is on the list
     * 
     * @param node: node to be removed
     */
    private void deleteNode(DLLNode<T> node) {
        if (this.size() == 1) {
            this.deleteOnlyElem();
            return;
        }
        if (this.current == node) {
            this.current = this.current.getForward();
        }
        if (this.head == node) {
            this.head = this.head.getForward();
        }
        DLLNode<T> forward = node.getForward();
        DLLNode<T> back = node.getBack();
        forward.setBack(back);
        back.setForward(forward);
        this.size --;
        return;
    }
	
    /**
     * Attempts to find the first node with data that equals the supplied data. Returns null if not found.
     * @param data: data to be compared to
     * @return Node in list if found. null if not found.
     */
    private DLLNode<T> findFirstNodeThatEquals(T data){
        if (this.size() == 0) {
            return null;
        }
        DLLNode<T> tempNode = this.head;
        do {
            if (tempNode.getInfo().equals(data)) {
                return tempNode;
            }
            tempNode = tempNode.getForward();
        } while (tempNode != this.head);
        return null;
    }
    
	// observers --------------------
    /**
     * Returns the size.
     * @return size
     */
    @Override
    public int size() {
        return this.size;
    }    
    
    /**
     * Returns whether if list contains an element, as specified by the objects equals() method 
     * @param element: element to be compared
     * @return whether if list contains an element compare-equal to the input
     */
    @Override
    public boolean contains(T element) {
        return (findFirstNodeThatEquals(element) != null);
    }    
    

    /**
     * Returns the first element in the list compare-equal to the input. If not found, return null.
     * @param element: element to be compared
     * @return first compare-equal element from the list. null if not found.
     */
    @Override
    public T get(T element) {
        DLLNode<T> tempNode = this.findFirstNodeThatEquals(element);
        if (tempNode == null) {
            return null;
        }
        return tempNode.getInfo();
    }
	
    /**
     * Returns an indexed new-line delimited string representation of the list
     * @return indexed string representation of the list
     */
    @Override
    public String toString() {
        int index = 0;
        String s = "";
        DLLNode<T> tempNode = this.head;
        do {
            s += index + ": " + tempNode.getInfo().toString() + "\n";
            index ++;
            tempNode = tempNode.getForward();
        } while (tempNode != this.head);
        return s;
    }
    
	// transformers --------------------
    /**
     * Add an element to the end of the list
     * Precondition: element is not null
     * @param element: element to be added to the list
     */
    @Override
    public void add(T element) {
        if (this.size() == 0) {
            this.createFirstElem(element);
            return;
        }
        DLLNode<T> node = new DLLNode<T>(element);
        node.setBack(this.head.getBack());
        node.setForward(this.head);
        this.head.getBack().setForward(node);
        this.head.setBack(node);
        this.size ++;
        return;
    }    
    
    /**
     * Removes the first occurence of compare-equal element from the list if found. Returns whether if there was one.
     * @param element: element to be compared
     * @return whether if there was a match to be removed
     */
    @Override
    public boolean remove(T element) {
        DLLNode<T> tempNode = this.findFirstNodeThatEquals(element);
        if (tempNode == null) {
            return false;
        }
        this.deleteNode(tempNode);
        return true;
    }
    
	// iterators --------------------
    /**
     * resets the iterator to its default state
     */
    @Override
    public void reset() {
        this.current = this.head;
        return;
    }
    
    /**
     * Iterates forward.
     * @return the next element to be iterated
     */
    @Override
    public T getNext() {
        T tempT = this.current.getInfo();
        this.current = this.current.getForward();
        return tempT;
    }
    
    /**
     * Iterates backward.
     * @return the previous element to be iterated.
     */
    @Override
    public T getPrevious() {
        this.current = this.current.getBack();
        return this.current.getInfo();
    }
	// --------------------
}
