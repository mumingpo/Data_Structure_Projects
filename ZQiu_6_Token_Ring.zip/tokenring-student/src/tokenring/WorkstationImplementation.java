// implemented by SQ on 06/28/2018
package tokenring;

import java.util.LinkedList;

public class WorkstationImplementation extends Workstation {

    private NetworkInterface nic;
    /*
     * addLast() adds element to the end of the list, similar to enqueue.
     * removeFirst() pops first element from the list, similar to dequeue
     */
    private LinkedList<Message> messages;
    
	public WorkstationImplementation(NetworkInterface nic) {
        this.nic = nic;
        this.messages = new LinkedList<Message>();
        return;
	}

	public NetworkInterface getNIC() {
	    return this.nic;
	}
	
	@Override
	public int compareTo(Workstation o) {
        return (this.id - o.id);
	}
	
	@Override
	public boolean equals(Object obj) {
        return (this.id == ((Workstation)obj).id);
	}

	public void sendMessage(Message m) {
	    this.messages.addLast(m);
	    return;
	}

	@Override
	public void tick() {
	    if (nic.hasFrame()) {
	        Frame f = nic.read();
	        if (f.isTokenFrame()) {
	            if (this.messages.isEmpty()) {
	                nic.write(f);
	                return;
	            } else {
	                DataFrame df = new DataFrame(this.messages.removeFirst());
	                nic.write(df);
	                incMsgSent();
	                return;
	            }
	        } else if (f.isDataFrame()) {
	            DataFrame df = (DataFrame) f;
	            Message m = df.getMessage();
	            if (m.getReceiver() == this.id) {
	                System.out.println("message " + m.toString() + " received by " + this.id + "; sent by " + m.getSender());
	                df.setReceived(true);
	                nic.write(df);
	                incMsgRcvd();
	            } else if (m.getSender() == this.id) {
	                if (df.wasReceived()) {
	                    System.out.println("message " + m.toString() + " acknowledged by sender " + this.id + " from destination " + m.getReceiver());
	                    nic.write(TokenFrame.TOKEN);
	                    incMsgDelivered();
	                } else {
	                    System.out.println("message " + m.toString() + " dropped; destination not reachable");
	                    nic.write(TokenFrame.TOKEN);
	                }
	            } else {
	                nic.write(df);
	            }
	        }
	    }
	}
}
