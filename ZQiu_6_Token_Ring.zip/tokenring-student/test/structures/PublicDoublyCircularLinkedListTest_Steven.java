// created by SQ on 06/28/2018
package structures;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PublicDoublyCircularLinkedListTest_Steven {

    private DoublyCircularLinkedListImplementation<String> emptyList;
    private DoublyCircularLinkedListImplementation<String> listWithOneElem;
    private DoublyCircularLinkedListImplementation<String> list123;
    
    @Before
    public void setup() {
        this.emptyList = new DoublyCircularLinkedListImplementation<String>();
        this.listWithOneElem = new DoublyCircularLinkedListImplementation<String>();
        this.listWithOneElem.add("chicken");
        this.list123 = new DoublyCircularLinkedListImplementation<String>();
        this.list123.add("1");
        this.list123.add("2");
        this.list123.add("3");
        return;
    }
    
    @Test (timeout = 100)
    public void testDoublyCircularLinkedListImplementation() {
        new DoublyCircularLinkedListImplementation<String>();
        return;
    }

    @Test (timeout = 100)
    public void testSize() {
        assertEquals("emptyList is empty.", 0, this.emptyList.size());
        assertEquals("listWithOneElem has one element.", 1, this.listWithOneElem.size());
        assertEquals("list123 has 3 elements.", 3, this.list123.size());
        return;
    }

    @Test (timeout = 500)
    public void testAdd() {
        this.emptyList.add("something");
        assertEquals("List should now be size 1.", 1, this.emptyList.size());
        this.listWithOneElem.add("something");
        assertEquals("List should now be size 2.", 2, this.listWithOneElem.size());
        this.list123.add("something");
        assertEquals("List should now be size 4.", 4, this.list123.size());
        return;
    }

    @Test (timeout = 500)
    public void testRemove() {
        assertFalse("You should not be able to remove null from a list.", this.emptyList.remove(null));
        assertFalse("You should not be able to remove anything from an empty list", this.emptyList.remove(""));
        assertFalse("Your remove method is finding inequal elements", this.listWithOneElem.remove("hen"));
        assertTrue("Your remove method doesn't quite work on list with 1 element.", this.listWithOneElem.remove("chicken"));
        assertEquals("Your remove method does not adjust size for list with size one.", 0, this.listWithOneElem.size());
        assertFalse("Your remove method is finding inequal elements", this.list123.remove("4"));
        assertTrue("Your remove method doesn't quite work.", this.list123.remove("1"));
        assertTrue("Your remove method doesn't quite work.", this.list123.remove("3"));
        assertEquals("Your remove method does not adjust size.", 1, this.list123.size());
    }

    @Test (timeout = 500)
    public void testContains() {
        assertFalse("Your contains method is testing positive for null.", this.listWithOneElem.contains(null));
        assertFalse("Your contains method is returning false positives.", this.listWithOneElem.contains("4"));
        assertFalse("Your contains method is returning false positives.", this.emptyList.contains("4"));
        assertTrue("Your contains method is returning false negatives.", this.listWithOneElem.contains("chicken"));
        assertTrue("Your contains method is returning false negatives.", this.list123.contains("1"));
        assertTrue("Your contains method is returning false negatives.", this.list123.contains("3"));
    }

    @Test (timeout = 500)
    public void testGet() {
        assertNull("get method should not get anything for null.", this.listWithOneElem.get(null));
        assertNull("get method should not get anything from an empty list", this.emptyList.get("turkey"));
        assertNull("get method should not get anything not on list", this.list123.get("turkey"));
        assertNotNull("Your get method is not getting thins when it's supposed to.", this.listWithOneElem.get("chicken"));
        assertNotNull("Your get method is not getting thins when it's supposed to.", this.list123.get("1"));
        assertNotNull("Your get method is not getting thins when it's supposed to.", this.list123.get("3"));
    }
    
    @Test (timeout = 2000)
    public void testGetReferencing() {
        class Circle implements Comparable<Circle> {
            protected int radius;
            protected String color;
            public Circle(int r, String c) {
                this.radius = r;
                this.color = c;
            }
            
            @Override
            public boolean equals(Object c) {
                return (this.radius == ((Circle)c).radius);
            }
            
            @Override
            public int compareTo(Circle c) {
                return (this.radius - c.radius);
            }
            
            public String getColor() {
                return this.color;
            }
        }
        DoublyCircularLinkedListImplementation<Circle> circleList = new DoublyCircularLinkedListImplementation<Circle>();
        circleList.add(new Circle(2, "Blue"));
        Circle c = new Circle(2, "Green");
        assertNotNull("get method should compare with equals method, not by reference.", circleList.get(c));
        assertEquals("get method should return object from the list, not the originial object", "Blue", circleList.get(c).getColor());
    }
    
    @Test (timeout = 500)
    public void testGetNext() {
        assertEquals("getNext method is not working properly", "chicken", this.listWithOneElem.getNext());
        assertEquals("getNext method is not working properly", "chicken", this.listWithOneElem.getNext());
        assertEquals("getNext method is not working properly", "1", this.list123.getNext());
        assertEquals("getNext method is not working properly", "2", this.list123.getNext());
        assertEquals("getNext method is not working properly", "3", this.list123.getNext());
        assertEquals("getNext method is not working properly", "1", this.list123.getNext());
    }
    
    @Test (timeout = 500)
    public void testGetPrevious() {
        assertEquals("getPrevious method is not working properly", "chicken", this.listWithOneElem.getPrevious());
        assertEquals("getPrevious method is not working properly", "chicken", this.listWithOneElem.getPrevious());
        assertEquals("getPrevious method is not working properly", "3", this.list123.getPrevious());
        assertEquals("getPrevious method is not working properly", "2", this.list123.getPrevious());
        assertEquals("getPrevious method is not working properly", "1", this.list123.getPrevious());
        assertEquals("getPrevious method is not working properly", "3", this.list123.getPrevious());
    }

    @Test (timeout = 500)
    public void testReset() {
        this.list123.getNext();
        this.list123.reset();
        assertEquals("reset method is not working properly", "1", this.list123.getNext());
        this.list123.getPrevious();
        this.list123.reset();
        assertEquals("reset method is not working properly", "1", this.list123.getNext());
    }
    
    @Test (timeout = 500)
    public void testIteratorWhenFirstElemIsRemoved() {
        this.list123.remove("1");
        this.list123.reset();
        assertEquals("Removal of first element should adjust list references accordingly", "2", this.list123.getNext());
    }
}
