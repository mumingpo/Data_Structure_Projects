// edited by SQ on 06/07/2018
package hanoi;

import structures.LinkedStack;
// import structures.StackInterface; Never used. more of a specification for LinkedStack
import java.lang.NullPointerException;

// implemented by SQ on 06/07/2018
/**
 * A {@link StackBasedHanoiPeg} is a {@link HanoiPeg} backed by a
 * {@link LinkedStack}
 * 
 * @author jcollard
 *
 */
public class StackBasedHanoiPeg implements HanoiPeg {
	
	private LinkedStack<HanoiRing> Peg;
	/**
	 * Creates a new {@link StackBasedHanoiPeg} that has no rings.
	 */
	public StackBasedHanoiPeg() {
		this.Peg = new LinkedStack<HanoiRing>();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addRing(HanoiRing ring) throws IllegalHanoiMoveException, NullPointerException {
		if (ring == null) {
			throw new NullPointerException("You do not simply add null to a Peg.");
		}
		if (Peg.getSize() > 0) {	
			if (Peg.peek().getSize() <= ring.getSize()) {
				throw new IllegalHanoiMoveException("Attempt to move a bigger ring onto a smaller ring.");
			}
		}
		Peg.push(ring);
		return;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public HanoiRing remove() throws IllegalHanoiMoveException {
		if (Peg.getSize() == 0) {
			throw new IllegalHanoiMoveException("Attempt to remove ring from an empty peg.");
		}
        return Peg.pop();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public HanoiRing getTopRing() throws IllegalHanoiMoveException {
		if (Peg.getSize() == 0) {
			throw new IllegalHanoiMoveException("Attempt to look up top ring from an empty peg.");
		}
        return Peg.peek();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean hasRings() {
        return (Peg.getSize() != 0);
	}
}
