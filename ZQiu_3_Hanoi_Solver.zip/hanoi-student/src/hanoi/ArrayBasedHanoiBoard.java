// implemented by SQ on 06/07/2018
package hanoi;

import java.lang.IllegalArgumentException;

/**
 * A {@link ArrayBasedHanoiBoard} is a simple implementation of
 * {@link HanoiBoard}
 * 
 * @author jcollard
 * 
 */
public class ArrayBasedHanoiBoard implements HanoiBoard {
	
	private StackBasedHanoiPeg[] Board;
	private final int numOfRings;

	/**
	 * Creates a {@link ArrayBasedHanoiBoard} with three empty {@link HanoiPeg}s
	 * and {@code n} rings on peg 0.
	 */
	public ArrayBasedHanoiBoard(int n) throws IllegalArgumentException{
		if (n < 0) {
			throw new IllegalArgumentException("Cannot create hanoi boards with a negative number of rings.");
		}
		this.Board = new StackBasedHanoiPeg[3];
		for (int i = 0; i < 3; i++) {
			this.Board[i] = new StackBasedHanoiPeg();
		}
		for (int i = n; i > 0; i--) {
			HanoiRing temp = new HanoiRing(i);
			this.Board[0].addRing(temp);
		}
		this.numOfRings = n;
		return;
	}

	@Override
	public void doMove(HanoiMove move) throws IllegalHanoiMoveException {
		try {
			HanoiRing temp;
			temp = this.Board[move.getFromPeg()].remove();
			this.Board[move.getToPeg()].addRing(temp);
		} catch (IllegalHanoiMoveException chicken) {
			throw new IllegalHanoiMoveException ("The move failed because \n" + chicken.getMessage());
		}
		return;
	}

	@Override
	public boolean isSolved() {
		// if the method below failed, I made some mistake elsewhere regarding the legality of moves
        if ((!this.Board[0].hasRings()) && (!this.Board[1].hasRings())){
        	return true;
        }
        return false;
	}

	/**
	 * <p>
	 * A {@link HanoiMove} is not legal if either is true:
	 * 
	 * <ul>
	 * <li>The from peg has no rings</li>
	 * <li>The to peg has rings AND the ring to be moved has a size larger than
	 * the topmost ring on the to peg.</li>
	 * </ul>
	 * 
	 * Otherwise, the move is legal.
	 * </p>
	 */
	@Override
	public boolean isLegalMove(HanoiMove move) {
        if (!this.Board[move.getFromPeg()].hasRings()) {
        	return false;
        }
        if (this.Board[move.getToPeg()].hasRings()) {
        	// ">=" until instructed otherwise
        	if (this.Board[move.getFromPeg()].getTopRing().getSize() >= this.Board[move.getToPeg()].getTopRing().getSize()) {
        		return false;
        	}
        }
        return true;
	}
}
