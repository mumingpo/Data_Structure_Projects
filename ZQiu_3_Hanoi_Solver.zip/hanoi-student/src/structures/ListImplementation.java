// edited by SQ on 06/07/2018
package structures;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.lang.NullPointerException;
import structures.ListNode;

/* criteria:
 * size(): O(1)
 * append(): O(1)
 * get(): O(n)
 * 
 * judging from the requirements, it seems that a linked list is the best way to implement this
 * oh right, it says that right below
 * silly me
 * */

/**
 * An {@code ListImplementation} is a Linked List that wraps {@link Node}s and
 * provides useful operations.
 * 
 * @author jcollard
 * 
 */
public class ListImplementation<T> implements ListInterface<T> {
	
	private int size; // so that I may have O(1) retrieval time
	private ListNode<T> first, last;
	
	public ListImplementation() {
		this.size = 0;
		this.first = null;
		this.last = null;
		return;
	}

	/**
	 * Returns the number of nodes in this list.
	 */
	@Override
	public int size() {
        return this.size;
	}

	@Override
	public boolean isEmpty() {
        return (this.size == 0);
	}

	/**
	 * Appends {@code elem} to the end of this {@code ListImplementation} and
	 * returns itself for convenience.
	 */
	@Override
	public ListImplementation<T> append(T elem) throws NullPointerException{
		if (elem == null) {
			throw new NullPointerException("Cannot append null.");
		}
		if (this.last == null) {
			this.first = new ListNode<T>(elem);
			this.last = this.first;
		} else {
			this.last.setNext(new ListNode<T>(elem));
			this.last = this.last.getNext();
		}
		this.size ++;
		return this;
	}

	/**
	 * Gets the {@code n}th element from this list.
	 */
	@Override
	public T get(int n) throws NoSuchElementException{
		if (n >= this.size || n < 0) {
			throw new NoSuchElementException("Index requested by \"get\" method is beyond the bounds of this list.");
		}
		ListNode<T> temp = this.first;
		for (int i = 0; i < n; i++) {
			temp = temp.getNext();
		}
		return temp.get();
	}

	// whaaaat?
	/**
	 * Returns an iterator over this list. The iterator does not support the
	 * {@code remove()} method.
	 */
	@Override
	public ListIterator<T> iterator() {
        return new ListIterator<T>(this);
	}
}

