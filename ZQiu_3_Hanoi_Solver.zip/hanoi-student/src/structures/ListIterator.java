// Created by SQ on 06/07/2018 without a clue what I'm doing
// https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html seems to suggest that I can implement according to some java.util.Iterator interface
// hmmmm let's try it

package structures;

// import java.util.Iterator; hmmmmm... java does not support import aliasing
// another reason to stick to python
// anyways, more stackoverflow.com time
// it seems like I can just implement the fully qualified name without importing
// I learned something today.
// on second thought, maybe Iterator is too prone to conflict
import java.util.NoSuchElementException;

public class ListIterator<T> implements java.util.Iterator<T> {
	
	private int currentIndex;
	private ListImplementation<T> List;
	
	public ListIterator(ListImplementation<T> list) {
		this.List = list;
		this.currentIndex = -1;
		return;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean hasNext() {
		if (this.currentIndex + 1 < this.List.size()) {
			return true;
		}
		return false;
	}

	// next() is O(n), but due to hiding I cannot access the actual ListNodes themselves, so I guess this is the best I can do
	/**
	 * {@inheritDoc}
	 */
	@Override
	public T next() throws NoSuchElementException{
		try {
			T temp = this.List.get(this.currentIndex + 1);
			// this happens strictly after the get operation as the current index should not change if the above failed
			this.currentIndex ++;
			return temp;
		} catch (NoSuchElementException chicken) {
			throw chicken; // I am such a terrible person
		}
	}
}
