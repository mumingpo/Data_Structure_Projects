// created by SQ on 06/07/2018 to facilitate ListImplementation's implementation
// and oh, silly me, what is that file under /support/structures called Node.java?
// well whatever.
package structures;

public class ListNode<T> {
	private T data;
	private ListNode<T> next;
	
	public ListNode() {
		this.data = null;
		this.next = null;
		return;
	}
	
	public ListNode(T datum) {
		this.data = datum;
		this.next = null;
		return;
	}
	
	public void setNext(ListNode<T> node) {
		this.next = node;
		return;
	}
	
	public void set(T datum) {
		this.data = datum;
		return;
	}
	
	public ListNode<T> getNext(){
		return this.next;
	}
	
	public T get() {
		return this.data;
	}
	
	public String toString() {
		return this.data.toString();
	}
}
