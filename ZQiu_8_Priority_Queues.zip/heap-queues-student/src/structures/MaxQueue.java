package structures;

import comparators.IntegerComparator;

import java.util.Comparator;
import java.util.Iterator;

public class MaxQueue<V> implements PriorityQueue<Integer, V> {
    
    private Comparator<Integer> comparator;
    private AbstractArrayHeap<Integer, V> heap;

    /**
     * Creates a MaxQueue as specified by IntegerComparator
     */
    public MaxQueue() {
        this.comparator = new IntegerComparator();
        this.heap = new StudentArrayHeap<Integer, V>(this.comparator);
        return;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public PriorityQueue<Integer, V> enqueue(Integer priority, V value) {
        this.heap.add(priority, value);
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public V dequeue() {;
        return this.heap.remove();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public V peek() {
        if (this.heap.isEmpty()) {
            throw new IllegalStateException("Cannot peek at an empty heap.");
        }
        return this.heap.peek();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Iterator<Entry<Integer, V>> iterator() {
        return this.heap.asList().iterator();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Comparator<Integer> getComparator() {
        return this.comparator;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int size() {
        return this.heap.size();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty() {
        return (this.heap.size() == 0);
    }
}
