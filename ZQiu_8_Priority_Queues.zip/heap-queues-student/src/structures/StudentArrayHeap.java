package structures;

import java.util.Comparator;

public class StudentArrayHeap<P, V> extends AbstractArrayHeap<P, V> {

    /**
     * {@inheritDoc}
     */
    public StudentArrayHeap(Comparator<P> comparator) {
        super(comparator);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected int getLeftChildOf(int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException("Index specified in getLeftChildOf method cannot be less than 0");
        }
        return index * 2 + 1;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected int getRightChildOf(int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException("Index specified in getRightChildOf method cannot be less than 0");
        }
        return index * 2 + 2;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected int getParentOf(int index) {
        if (index < 1) {
            throw new IndexOutOfBoundsException("Index specified in getParentOf method cannot be less than 1");
        }
        return (index - 1) / 2;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void bubbleUp(int index) {
        if (index == 0) {
            return;
        }
        int parent = this.getParentOf(index);
        if (this.comparator.compare(this.heap.get(index).getPriority(), this.heap.get(parent).getPriority()) > 0) {
            super.swap(index, parent);
            /*Entry<P, V> temp = this.heap.get(parent);
            this.heap.set(parent, this.heap.get(index));
            this.heap.set(index, temp);*/
            this.bubbleUp(parent);
        }
        return;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void bubbleDown(int index) {
        int larger_child;
        int lc = this.getLeftChildOf(index);
        int rc = this.getRightChildOf(index);
        if (lc >= this.heap.size()) {
            return;
        }
        if (rc >= this.heap.size()) {
            larger_child = lc;
        } else {
            if (this.comparator.compare(this.heap.get(lc).getPriority(), this.heap.get(rc).getPriority()) >= 0) {
               larger_child = lc;
            } else {
                larger_child = rc;
            }
        }
        if (this.comparator.compare(this.heap.get(index).getPriority(), this.heap.get(larger_child).getPriority()) < 0) {
            super.swap(index, larger_child);
            /*Entry<P, V> temp = this.heap.get(larger_child);
            this.heap.set(larger_child, this.heap.get(index));
            this.heap.set(index, temp);*/
            this.bubbleDown(larger_child);
        }
        return;
    }
}

