package comparators;

import static org.junit.Assert.*;

import java.util.Comparator;
import org.junit.Test;

public class ReverseIntegerComparatorTest_Steven {
    private static final Comparator<Integer> C = new ReverseIntegerComparator();
    @Test
    public void test() {
        assertTrue(C.compare(1, 0) < 0);
        assertTrue(C.compare(0, 0) == 0);
        assertTrue(C.compare(0, 1) > 0);
        assertTrue(C.compare(2147483647, -123) < 0);
        assertTrue(C.compare(-2147483648, 123) > 0);
        assertTrue(C.compare(-2147483648, 2147483647) > 0);
    }
}
