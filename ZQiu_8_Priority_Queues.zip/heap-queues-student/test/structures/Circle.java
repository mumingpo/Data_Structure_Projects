package structures;

public final class Circle implements Comparable<Circle> {
    private static int IDS = 0;
    private final int id;
    private final int radius;
    private final String color;
    
    public Circle(int r) {
        this.radius = r;
        this.color = "white";
        this.id = Circle.IDS;
        Circle.IDS ++;
    }
    
    public Circle(int r, String c) {
        this.radius = r;
        this.color = c;
        this.id = Circle.IDS;
        Circle.IDS ++;
    }
    
    public Circle(Circle c) {
        this.radius = c.getRadius();
        this.color = c.getColor();
        this.id = Circle.IDS;
        IDS ++;
    }
    
    @Override
    public boolean equals(Object c) {
        return (this.radius == ((Circle)c).getRadius());
    }
    
    @Override
    public int compareTo(Circle c) {
        return (this.radius - c.getRadius());
    }
    
    public String getColor() {
        return this.color;
    }
    
    public int getRadius() {
        return this.radius;
    }
    
    public int getID() {
        return this.id;
    }
    
    public static int getIDS() {
        return IDS;
    }
    
    public String toString() {
        return "\"" + this.radius + "<" + this.id + ">\"";
        //return ("Circle_" + this.id + "_" + this.radius + "_" + this.color);
    }
}