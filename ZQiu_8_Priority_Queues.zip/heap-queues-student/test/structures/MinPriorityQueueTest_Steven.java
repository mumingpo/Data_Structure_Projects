/**
 * 
 */
package structures;

import static org.junit.Assert.*;

import org.junit.Test;
import java.util.Random;

import comparators.ReverseIntegerComparator;

/**
 * @author mumin
 *
 */
public class MinPriorityQueueTest_Steven {
    
    private static Random rng = new Random();
    
    private PriorityQueue<Integer, Circle> q;
    
    @Test
    public void testMinEmpty() {
        this.q = new MinQueue<Circle>();
        assertEquals(0, this.q.size());
        assertTrue(this.q.isEmpty());
        assertFalse(q.iterator().hasNext());
        return;
    }
    
    @Test
    public void testMinEnqueueSizeDequeueEmpty() {
        this.q = new MinQueue<Circle>();
        assertEquals(this.q, this.q.enqueue(0, new Circle(5)));
        assertEquals(this.q, this.q.enqueue(1, new Circle(3)));
        assertEquals(2, this.q.size());
        assertFalse(this.q.isEmpty());
        assertEquals(new Circle(5, "Blue"), this.q.peek());
        assertEquals(new Circle(5, "Blue"), this.q.dequeue());
        assertEquals(new Circle(3, "Orange"), this.q.peek());
        assertEquals(new Circle(3, "Orange"), this.q.dequeue());
        assertEquals(0, this.q.size());
        assertTrue(this.q.isEmpty());
        return;
    }
    
    @Test (expected = NullPointerException.class)
    public void testMinEnqueueNPE() {
        this.q = new MinQueue<Circle>();
        this.q.enqueue(1, null);
        return;
    }
    
    @Test (expected = IllegalStateException.class)
    public void testMinDequeueISE() {
        this.q = new MinQueue<Circle>();
        this.q.dequeue();
        return;
    }
    
    @Test (expected = IllegalStateException.class)
    public void testMinPeekISE() {
        this.q = new MinQueue<Circle>();
        this.q.peek();
        return;
    }
    
    @Test
    public void testMinIterator() {
        this.q = new MinQueue<Circle>();
        java.util.Iterator<Entry<Integer, Circle>> it;
        java.util.ArrayList<Circle> list1 = new java.util.ArrayList<Circle>(), 
                list2 = new java.util.ArrayList<Circle>();
        for (int i = 0; i < 100; i++) {
            Circle c = new Circle(rng.nextInt(50));
            int priority = rng.nextInt(50);
            list1.add(c);
            this.q.enqueue(priority, new Circle(c));
        } 
        it = this.q.iterator();
        while (it.hasNext()) {
            list2.add(it.next().getValue());
        }
        java.util.Collections.sort(list1);
        java.util.Collections.sort(list2);
        assertEquals(list1.size(), list2.size());
        for (int i = 0; i < list1.size(); i++) {
            assertEquals(list1.get(i), list2.get(i));
        }
        return;
    }
    
    @Test (expected = UnsupportedOperationException.class)
    public void testMinIteratorUOE() {
        this.q = new MinQueue<Circle>();
        this.q.iterator().remove();
    } 
    
    @Test
    public void testGetComparator() {
        this.q = new MinQueue<Circle>();
        assertEquals(ReverseIntegerComparator.class, this.q.getComparator().getClass());
        return;
    }
    
    @Test
    public void testRandomizedPriorityQueues() {
        final int TOTAL_ITERATIONS = 1000;
        for (int i = 0; i < TOTAL_ITERATIONS; i ++) {
            final int SIZE = rng.nextInt(10000) + 1;
            final int MAX_RADIUS = SIZE / 10 + 1;
            
            java.util.ArrayList<Entry<Integer, Circle>> list = new java.util.ArrayList<Entry<Integer, Circle>>(), 
                    shuffledList = new java.util.ArrayList<Entry<Integer, Circle>>();
            this.q = new MinQueue<Circle>();
            
            for (int priority = 0; priority < SIZE; priority++) {
                Entry<Integer, Circle> e = new Entry<Integer, Circle>(priority, new Circle(rng.nextInt(MAX_RADIUS) + 1));
                list.add(e);
                shuffledList.add(e);
            }
            java.util.Iterator<Entry<Integer, Circle>> it = list.iterator();
            java.util.Collections.shuffle(shuffledList);
            for (Entry<Integer, Circle> e: shuffledList) {
                this.q.enqueue(e.getPriority(), e.getValue());
            }
            while (it.hasNext()) {
                assertEquals(it.next().getValue(), this.q.dequeue());
            }
            assertTrue(this.q.isEmpty());   
        }
    }
}
