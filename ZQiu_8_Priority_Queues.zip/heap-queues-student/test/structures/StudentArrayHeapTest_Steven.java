package structures;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import comparators.*;

public class StudentArrayHeapTest_Steven {
    private static final java.util.Comparator<Integer> C = new IntegerComparator();
    private static final java.util.Random rng = new java.util.Random();

    private AbstractArrayHeap<Integer, Circle> heap;
    
    @Before
    public void setup() {
        this.heap = new StudentArrayHeap<Integer, Circle>(C);
        for (int i = 100; i < 200; i++) {
            this.heap.add(i, new Circle(i));
        }
        return;
    }
    
    @Test
    public void testConstructor() {
        this.heap = new StudentArrayHeap<Integer, Circle>(C);
    }
    
    @Test
    public void testAddSizeRemoveIsEmpty() {
        assertEquals(100, this.heap.size());
        assertFalse(this.heap.isEmpty());
        this.heap.add(200, new Circle(200));
        this.heap.add(99, new Circle(99));
        assertEquals(102, this.heap.size());
        for (int i = 200; i >= 99; i --) {
            assertEquals(new Circle(i), this.heap.remove());
        }
        assertEquals(0, this.heap.size());
        assertTrue(this.heap.isEmpty());
    }
    
    @Test
    public void testGetComparator() {
        assertEquals(C, this.heap.getComparator());
    }
    
    @Test
    public void testRandomizedPriorityQueues() {
        final int TOTAL_ITERATIONS = 1000;
        for (int i = 0; i < TOTAL_ITERATIONS; i ++) {
            final int SIZE = rng.nextInt(10000) + 1;
            final int MAX_RADIUS = SIZE / 10 + 1;
            
            java.util.ArrayList<Entry<Integer, Circle>> list = new java.util.ArrayList<Entry<Integer, Circle>>(), 
                    shuffledList = new java.util.ArrayList<Entry<Integer, Circle>>();
            this.heap = new StudentArrayHeap<Integer, Circle>(C);
            
            for (int priority = SIZE; priority > 0; priority--) {
                Entry<Integer, Circle> e = new Entry<Integer, Circle>(priority, new Circle(rng.nextInt(MAX_RADIUS) + 1));
                list.add(e);
                shuffledList.add(e);
            }
            java.util.Iterator<Entry<Integer, Circle>> it = list.iterator();
            java.util.Collections.shuffle(shuffledList);
            for (Entry<Integer, Circle> e: shuffledList) {
                this.heap.add(e.getPriority(), e.getValue());
            }
            while (it.hasNext()) {
                assertEquals(it.next().getValue(), this.heap.remove());
            }
            assertTrue(this.heap.isEmpty());   
        }
    }    
}
