// Created by SQ on 06/22/2018

package structures;

import java.util.Iterator;

public class RecursiveListIterator<T> implements Iterator<T> {

    // data
    private ListNode<T> node;
    
    // constructor
    public RecursiveListIterator(ListNode<T> node) {
        this.node = node;
        return;
    }
    
    // iterator methods
    @Override
    public boolean hasNext() {
        return ((this.node != null) && (this.node.getNext() != null));
    }

    @Override
    public T next() throws UnsupportedOperationException{
        if (!hasNext()) {
            throw new UnsupportedOperationException("Calling next() in iterator with no more elements to return.");
        }
        T temp = this.node.getData();
        this.node = this.node.getNext();
        return temp;
    }
   
    @Override
    public void remove() throws UnsupportedOperationException{
        throw new UnsupportedOperationException("Remove is not supported during iteration.");
    }
}
