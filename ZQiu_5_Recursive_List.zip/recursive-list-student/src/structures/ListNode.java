// created by SQ on 06/22/2018
package structures;

public class ListNode<T> {
    
    // data
    private T data;
    private ListNode<T> next;
    
    // constructors
    public ListNode() {
        this.data = null;
        this.next = null;
        return;
    }
    
    public ListNode(T data) {
        this.data = data;
        this.next = null;
        return;
    }
    
    public ListNode(ListNode<T> next) {
        this.data = null;
        this.next = next;
        return;
    }
    
    public ListNode(T data, ListNode<T> next) {
        this.data = data;
        this.next = next;
        return;
    }
    
    // spectators
    public T getData() {
        return this.data;
    }
    
    public ListNode<T> getNext() {
        return this.next;
    }
    
    // modifiers
    public void setData(T data) {
        this.data = data;
        return;
    }
    
    public void setNext(ListNode<T> next) {
        this.next = next;
        return;
    }
}
