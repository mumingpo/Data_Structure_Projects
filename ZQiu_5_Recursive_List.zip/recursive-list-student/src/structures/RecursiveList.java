// created by SQ on 06/22/2018
// modified by SQ on 06/23/2018
// edited by SQ on 06/23/2018 for clarity.

package structures;

import java.util.Iterator;

public class RecursiveList<T> implements ListInterface<T>{

    /*
     * Requirements for this assignment:
     * size() = O(1)
     * insertFirst() = O(1)
     * insertLast() = O(size())
     * insertAt() = O(index)
     * removeFirst() = O(1)
     * removeLast() = O(size())
     * removeAt() = O(index)
     * getFirst() = O(1)
     * getLast() = O(size())
     * get() = O(index)
     * remove() = O(size())
     * indexOf() = O(size())
     * isEmpty() = O(1)
     * 
     * Judging from the requirement which requires O(1) time for certain insertions, I should implement it with a linked-list.
     * And no iteration?
     * Groan.
     * Again?
     */
    
    // data
    private ListNode<T> first;
    // justification: O(1) time for size()
    private int size;
    
    // helper function
    /**
     * Returns the node {@code numOfElems} after the current node.
     * 
     * Precondition: there are at least {@code numOfElems} nodes after the current node
     * Time-complexity: O(numOfElems)
     * 
     * @param node: current node
     * @param numOfElems: number of elements after the current node. 0 for the current node itself.
     * @return reference to node {@code numOfElems} after the current node.
     */
    private ListNode<T> numElemAfter(ListNode<T> node, int numOfElems){
        if (numOfElems == 0) {
            return node;
        }
        return (numElemAfter(node.getNext(), numOfElems - 1));
    }
    
    /**
     * Attempts to find a node where {@code data.equals(newNode.getData())} returns true and returns the index relative to the current node.
     * Returns -1 if not found.
     * Checks current node.
     * 
     * Time-complexity: O(length of the linked list)
     * 
     * @param node: current node
     * @param data: data for comparison
     * @param numOfElems: helper variable for recursion. should be set to 0 during outside function call.
     * @return index starting at 0 relative to the current node. -1 if not found.
     */
    private int numElemAfterIsCongruent(ListNode<T> node, T data, int numOfElems) {
        if (node.getData().equals(data)) {
            return numOfElems;
        } else if (node.getNext() == null) {
            return -1;
        }
        return this.numElemAfterIsCongruent(node.getNext(), data, numOfElems + 1);
    }
    /**
     * Returns the node right before the first node where {@code data.equals(newNode.getData())} returns true for easier manipulation
     * returns null if not found
     * does not check current node. 
     * 
     * Time-complexity: O(length of the linked list)
     * 
     * @param node: current node.
     * @param data: data for comparison
     * @return: node before the first node where {@code data.equals(newNode.getData())} returns true. null if not found.
     */
    private ListNode<T> accessNodeBeforeFirstCongruentElement(ListNode<T> node, T data){
        if (node.getNext() == null) {
            return null;
        } else if (node.getNext().getData().equals(data)) {
            return node;
        }
        return this.accessNodeBeforeFirstCongruentElement(node.getNext(), data);
    }
    
    // constructor
    public RecursiveList() {
        this.first = null;
        this.size = 0;
    }
    
    // construct iterator
    /**
     * {@inheritDoc}
     */
    @Override
    public Iterator<T> iterator() {
        return new RecursiveListIterator<T>(this.first);
    }

    // spectators
    /**
     * {@inheritDoc}
     */
    @Override
    public int size() {
        return this.size;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T getFirst() throws IllegalStateException{
        if (this.isEmpty()) {
            throw new IllegalStateException("getFirst() method attempted on an empty list.");
        }
        return this.first.getData();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T getLast() throws IllegalStateException{
        if (this.isEmpty()) {
            throw new IllegalStateException("getLast() method attempted on an empty list.");
        }
        // the index of the last element relative to the first is this.size - 1
        return this.numElemAfter(this.first, this.size - 1).getData();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T get(int i) throws IndexOutOfBoundsException{
        if ((i < 0) || (i >= this.size)) {
            throw new IndexOutOfBoundsException("The index accessed by the get() method is beyond the bounds of this list.");
        }
        return this.numElemAfter(first, i).getData();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int indexOf(T elem) throws NullPointerException{
        if (elem == null) {
            throw new NullPointerException("The element provided to the indexOf() method cannot be null.");
        }
        return this.numElemAfterIsCongruent(this.first, elem, 0);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty() {
        return (this.size == 0);
    }

    // modifiers
    /**
     * {@inheritDoc}
     */
    @Override
    public ListInterface<T> insertFirst(T elem) throws NullPointerException{
        if (elem == null) {
            throw new NullPointerException("The element provided to the insertFirst() method cannot be null.");
        }
        // no need for special cases for this.size == 0
        this.first = new ListNode<T>(elem, this.first);
        this.size ++;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ListInterface<T> insertLast(T elem) throws NullPointerException{
        if (elem == null) {
            throw new NullPointerException("The element provided to the insertLast() method cannot be null.");
        }
        if (this.size == 0) {   // identical to insertFirst
            this.first = new ListNode<T>(elem);
        } else {
            // numElemAfter finds the current last node.
            this.numElemAfter(this.first, this.size - 1).setNext(new ListNode<T>(elem));
        }
        this.size ++;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ListInterface<T> insertAt(int index, T elem) throws NullPointerException, IndexOutOfBoundsException{
        if (elem == null) {
            throw new NullPointerException("The element provided to the insertAt() method cannot be null.");
        }
        if ((index < 0) || (index > this.size)) {   // You can insert at index == this.size, which is the case of insertLast
            throw new IndexOutOfBoundsException("The index accessed by the insertAt() method is beyond the bounds of this list.");
        }
        // if-else statement deleted by SQ on 06/23 due to redundancy
        //if (this.size == 0) {   // "insertFirst"
        //    this.first = new ListNode<T>(elem);
        //} else {
        // all right, it seems that what was causing all that problem is failing to consider insertAt index 0
        // thank you for figuring out the problem
        // Maybe I should really also fix my JUnit tests so that it can better reflect those errors in the future.
        if (index == 0) {   // "insertFirst"
            this.first = new ListNode<T>(elem, this.first);
        } else {
            // numElemAfter finds the node before the to-be-inserted element
            ListNode<T> tempNode = this.numElemAfter(this.first, index - 1);
            // links the node with the new node with a link to the next node
            tempNode.setNext(new ListNode<T>(elem, tempNode.getNext()));
        }
        //}
        this.size ++;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T removeFirst() throws IllegalStateException{
        if (this.isEmpty()) {
            throw new IllegalStateException("removeFirst() method attempted on an empty list.");
        }
        // no need for special cases for this.size == 1
        // edited by SQ on 06/23 for consistency (a.k.a. no particular reason)
        T tempT = this.first.getData();
        //ListNode<T> temp = this.first;
        // "skip the first" to delete
        this.first = this.first.getNext();
        this.size --;
        //return temp.getData();
        return tempT;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T removeLast() throws IllegalStateException{
        if (this.isEmpty()) {
            throw new IllegalStateException("removeLast() method attempted on an empty list.");
        }
        T tempT;
        if (this.size == 1) {
            // numElemAfter cannot access the node before the first node, so a special case must be written
            tempT = this.first.getData();
            this.first = null;
        } else {
            // finding the second-to-the-last node
            ListNode<T> tempNode = this.numElemAfter(first, this.size - 2);
            tempT = tempNode.getNext().getData();
            // delete reference to the last element
            tempNode.setNext(null);
        }
        this.size --;
        return tempT;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T removeAt(int i) throws IndexOutOfBoundsException{
        if ((i < 0) || (i >= this.size)) {
            throw new IndexOutOfBoundsException("The index accessed by the removeAt() method is beyond the bounds of this list.");
        }
        T tempT;
        // if-else statement removed by SQ on 06/23 for redundancy
        //if (this.size == 1) {
            // numElemAfter cannot access the node before the first node, so a special case must be written
        //    tempT = this.first.getData();
        //    this.first = null;
        //} else {
        if (i == 0) {
            tempT = this.first.getData();
            // "skip the first node" to delete
            this.first = this.first.getNext();
        } else {
            // finding the node before the to-be-deleted node
            ListNode<T> tempNode = this.numElemAfter(first, i - 1);
            tempT = tempNode.getNext().getData();
            // "skip the node" to delete
            // no special case needed for delete the last node as this will set the reference of second-to-last node to null.
            tempNode.setNext(tempNode.getNext().getNext());
        }
        //}
        this.size --;
        return tempT;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean remove(T elem) throws NullPointerException{
        if (elem == null) {
            throw new NullPointerException("The element provided to the remove() method cannot be null.");
        }
        // decided to make the remove process and processing when found separate for clarity purposes
        boolean found;
        if (this.size == 0){
            found = false;
        } else if (this.size == 1) {
            if (this.first.getData().equals(elem)) {
                this.first = null;
                found = true;
            } else {
                found = false;
            }
        } else {
            if (this.first.getData().equals(elem)) {
                // "skip the first" to delete
                this.first = this.first.getNext();
                found = true;
            } else {
                // if found, temp will point to the node before the first equal element
                ListNode<T> temp = this.accessNodeBeforeFirstCongruentElement(this.first, elem);
                if (temp == null) {
                    found = false;
                } else {
                    // "skip the node" to delete
                    temp.setNext(temp.getNext().getNext());
                    found = true;
                }
            }
        }
        if (found) {
            this.size --;
        }
        return found;
    }
}
