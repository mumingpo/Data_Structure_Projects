// modified by SQ on 06/22/2018
// modified by SQ on 06/23/2018 to fix the positioning for asserEquals and add missing tests for boundary conditions
package structures;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class PublicListInterfaceTest {

	private ListInterface<String> list;
	// lists below added by SQ on 06/22
	private ListInterface<Integer> list123;
	private ListInterface<String> listString4321;

	@Before
	public void setup(){
          list = new RecursiveList<String>();
          list123 = new RecursiveList<Integer>();
          list123.insertLast(1);
          list123.insertLast(2);
          list123.insertLast(3);
          listString4321 = new RecursiveList<String>();
          listString4321.insertFirst("1");
          listString4321.insertFirst("2");
          listString4321.insertFirst("3");
          listString4321.insertFirst("4");
	}

	@Test (timeout = 500)
	public void testInsertFirstIsEmptySizeAndGetFirst1() {
		assertTrue("Newly constructed list should be empty.", list.isEmpty());
		assertEquals("Newly constructed list should be size 0.", 0, list.size());
		assertEquals("Insert First should return instance of self", list, list.insertFirst("hello"));
		assertFalse("List should now have elements.", list.isEmpty());
		assertEquals("List should now have 1 element.", 1, list.size());
		assertEquals("First element should .equals \"hello\".", "hello", list.getFirst());
		list.insertFirst("world");
		assertEquals(2, list.size());
		list.insertFirst("foo");
		assertEquals(3, list.size());
		assertEquals("First element should .equals \"foo\".", "foo", list.getFirst());
	}
	
	// tests below added by SQ on 06/22
	// tests below modified by SQ on 06/23
	@Test
	public void testSize() {
	    assertFalse("List is not empty.", this.list123.isEmpty());
	    assertEquals("List size should be 3", 3, this.list123.size());
        assertEquals("List size should be 4", 4, this.listString4321.size());
	}
    
    @Test (expected = NullPointerException.class)
    public void testInsertGetRemoveFirstSizeAndNullException() {
        assertEquals("First element should be 1", 1, (int)this.list123.getFirst());
        assertEquals("First element should be \"4\"", "4", this.listString4321.getFirst());
        assertEquals("List size should be 4", 4, this.list123.insertFirst(6).size());
        assertEquals("List size should be 5", 5, this.listString4321.insertFirst("6").size());
        assertEquals("First element should be 6", 6, (int)this.list123.removeFirst());
        assertEquals("First element should be \"6\"", "6", this.listString4321.removeFirst());
        assertEquals("List size should be 3", 3, this.list123.size());
        assertEquals("List size should be 4", 4, this.listString4321.size());
        this.list123.insertFirst(null);
    }
    
    @Test (expected = NullPointerException.class)
    public void testInsertGetRemoveLastSizeAndNullException() {
        assertEquals("Last element should be 3", 3, (int)this.list123.getLast());
        assertEquals("Last element should be \"1\"", "1", this.listString4321.getLast());
        assertEquals("List size should be 4", 4, this.list123.insertLast(6).size());
        assertEquals("List size should be 5", 5, this.listString4321.insertLast("6").size());
        assertEquals("Last element should be 6", 6, (int)this.list123.removeLast());
        assertEquals("Last element should be \"6\"", "6", this.listString4321.removeLast());
        assertEquals("List size should be 3", 3, this.list123.size());
        assertEquals("List size should be 4", 4, this.listString4321.size());
        this.list123.insertLast(null);
    }
    
    @Test (expected = NullPointerException.class)
    public void testInsertGetRemoveAtSizeAndNullException() {
        assertEquals("2nd element should be 2", 2, (int)this.list123.get(1));
        assertEquals("2nd element should be \"3\"", "3", this.listString4321.get(1));
        assertEquals("List size should be 4", 4, this.list123.insertAt(0, 6).size());
        assertEquals("List size should be 5", 5, this.listString4321.insertAt(1, "6").size());
        assertEquals("2nd element should be 1", 1, (int)this.list123.removeAt(1));
        assertEquals("2nd element should be \"6\"", "6", this.listString4321.removeAt(1));
        assertEquals("List size should be 3", 3, this.list123.size());
        assertEquals("List size should be 4", 4, this.listString4321.size());
        this.list123.insertAt(0, null);
    }
    
    @Test (expected = NullPointerException.class)
    public void testRemoveAndNullException() {
        assertTrue("List should have element 2", this.list123.remove(2));
        assertFalse("List should no longer have element 2", this.list123.remove(2));
        // test added by SQ on 06/23
        assertEquals("List size should now be 2", 2, this.list123.size());
        this.list123.remove(null);
    }
    
    @Test (expected = NullPointerException.class)
    public void testIndexOfAndNullException() {
        assertEquals("Index of 2 should be 1.", 1, this.list123.indexOf(2));
        assertEquals("index of \"2\" should be 2", 2, this.listString4321.indexOf("2"));
        this.list123.indexOf(null);
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testGetIOOBE() {
        this.list123.get(3);
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testRemoveAtIOOBE() {
        this.list123.removeAt(-1);
    }
    
    @Test (expected = IndexOutOfBoundsException.class)
    public void testInsertAtIOOBE() {
        this.list123.insertAt(4, 6);
    }
    
    @Test (expected = IllegalStateException.class)
    public void testRemoveException() {
        this.list123.removeFirst();
        this.list123.removeLast();
        this.list123.removeAt(0);
        assertTrue("List should be empty now.", this.list123.isEmpty());
        this.list123.removeFirst();
    }    
    
    @Test (expected = IllegalStateException.class)
    public void testGetException() {
        this.list123.removeFirst();
        this.list123.removeLast();
        this.list123.removeAt(0);
        assertEquals("List should be empty now.", this.list123.size(), 0);
        this.list123.getFirst();
    }
    
    @Test (expected = UnsupportedOperationException.class)
    public void testIteratorAndException() {
        java.util.Iterator<Integer> chicken = this.list123.iterator();
        assertTrue(chicken.hasNext());
        assertEquals("First chicken is 1", 1, (int)chicken.next());
        assertEquals(2, (int)chicken.next());
        assertEquals(3, (int)chicken.next());
        assertFalse(chicken.hasNext());
        chicken.next();
    }
    
    // added by SQ on 06/23 for testing boundary conditions
    @Test
    public void testBoundaryConditions() {
        this.list123.insertAt(0, 5);
        this.list123.insertAt(4, 6);
        assertEquals("List size should now be 5", 5, list123.size());
        assertEquals("First element of the list should be 5", 5, (int)list123.removeAt(0));
        assertEquals("Last element of the list should be 6", 6, (int)list123.removeAt(3));
        assertEquals("Last element of the list should be 3", 3, (int)list123.get(2));
        assertTrue(list123.remove(3));
        assertTrue(list123.remove(2));
        assertTrue(list123.remove(1));
        list123.insertFirst(3);
        assertEquals("First element should be 3", 3, (int)list123.getFirst());
        list123.removeFirst();
        list123.insertLast(7);
        assertEquals("Last element should be 7", 7, (int)list123.getLast());
        list123.removeLast();
        list123.insertAt(0, 9);
        assertEquals("Element should be 9", 9, (int)list123.removeAt(0));
        assertTrue(list123.isEmpty());
    }
}
