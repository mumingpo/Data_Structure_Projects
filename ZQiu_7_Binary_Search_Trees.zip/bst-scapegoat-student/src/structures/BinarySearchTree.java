// reorganized and modified by SQ on 07/04/2018
// modified by SQ on 07/08/2018
package structures;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

/* 
 * The assignment itself is not that challenging.
 * But what if I want to make the fundamental methods auto-optimizing?
 * 
 * Optimized trees are balanced and flush left.
 * 
 * Challenges to overcome:
 *      Removing a remote location may affect the tree as a whole, and I must keep checking how much should I modify in order to restore optimal structure
 *      Sounds like I need to climb up and down the tree, which means an added access to parent.
 *      Keeping track of each node as a L_CHILD/R_CHILD/ROOT for less comparisons
 *      Keep operations O(log(size_of_the_tree))
 *      I am considering "last element" and such a lot in my algorithms, which means a way to use indexing to find stuff in my tree (shouldn't be that hard) while moving things around (much more complicated)
 *      
 * Algorithm:
 *      Operations that make changes to the tree are addition and removal of nodes.
 *      Removal sounds easier, let's consider removal first:
 *      
 *      Removal:
 *          If removing the last element of the tree in in-order traversal, remove it and nothing more needs to be done.
 *          Otherwise, when you remove an element, the operation leaves a "hole" to be filled
 *          There are 2 cases to consider for "patching the hole":
 *              1. When the last element of the tree belongs to the sub-tree from the node:
 *                  1.1. When the last element belongs to the left sub-tree from the node:
 *                      Fill in the "hole" with the largest value of the left sub-tree
 *                      Remove the largest value of the left sub-tree (enter tail-recursion)
 *                  1.2. When the last element belongs to the right sub-tree from the node:
 *                      Fill in the "hole" with the smallest value of the right sub-tree
 *                      Remove the largest value of the right sub-tree (enter tail-recursion)
 *              2. When the last element of the tree doesn't belong to the sub-tree from the node:
 *                  1.1. When the node was a L_CHILD:
 *                      <strike>Replace node with parent and entering recursion? Now I'm breaking both sub-trees. doesn't work.</strike>
 *                      
 * ->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->
 *   _____ _____  _____  _____  _____  _____  _____  _____    _   _   _   _   _
 *  / ____|  __ \|  __ \|  __ \|  __ \|  __ \|  __ \|  __ \  | | | | | | | | | |
 * | |  __| |__) | |__) | |__) | |__) | |__) | |__) | |__) | | | | | | | | | | |
 * | | |_ |  _  /|  _  /|  _  /|  _  /|  _  /|  _  /|  _  /  | | | | | | | | | |
 * | |__| | | \ \| | \ \| | \ \| | \ \| | \ \| | \ \| | \ \  |_| |_| |_| |_| |_|
 *  \_____|_|  \_\_|  \_\_|  \_\_|  \_\_|  \_\_|  \_\_|  \_\ (_) (_) (_) (_) (_)
 *
 * Just counted the number of operations it takes to remove the smallest element from an optimal 15-element-tree. The operation cannot be reduced from O(size_of_the_tree). 
 * I've been wasting time and scratch paper trying to do the impossible.
 * This should have been equivalent to removing an element from a continuous, indexed list. I should have known better.
 * Designing algorithms is hard =/
 * Guess I will just do the assignment and worry about balancing later.
 * ->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->
 */

public class BinarySearchTree<T extends Comparable<T>> implements
		BSTInterface<T> {
    
    // variable declarations --------------------
	protected BSTNode<T> root;
	
	// constructors --------------------
	public BinarySearchTree() {
	    this.root = null;
	}
	
	// helper functions --------------------
	/**
	 * Returns the size of the sub-tree rooted from {@code node}
	 * @param node: root of the sub-tree to measure
	 * @return: size of the sub-tree
	 */
    protected int subtreeSize(BSTNode<T> node) {
        if (node == null) {
            return 0;
        } else {
            return 1 + subtreeSize(node.getLeft())
                    + subtreeSize(node.getRight());
        }
    }
    /**
     * Removes the largest element from the sub-tree rooted from {@code node}
     * Precondition: {@code node} must not be null
     * @param node: root of the sub-tree
     * @return Left child for the last node if there is one, null otherwise. Used for internal tree-preservation.
     */
    private BSTNode<T> removeRightmost(BSTNode<T> node) {
        // node must not be null
        if (node.getRight() == null) {
            return node.getLeft();
        } else {
            node.setRight(removeRightmost(node.getRight()));
            return node;
        }
    }

    /**
     * Get the highest value from the sub-tree rooted from {@code node}
     * Precondition: {@code node} must not be null
     * @param node: root of the sub-tree to measure
     * @return: highest value of the sub-tree
     */
    private T getHighestValue(BSTNode<T> node) {
        if (node.getRight() == null) {
            return node.getData();
        } else {
            return getHighestValue(node.getRight());
        }
    }
    
    /**
     * Removes a node with value {@code t} from the tree and adjust the tree accordingly to maintain the properties of a BST
     * Precondition: {@code node} must not be null
     * @param node: root of the sub-tree to look for t
     * @param t: the data to be compared to
     * @return:
     */
    private BSTNode<T> removeFromSubtree(BSTNode<T> node, T t) {
        int result = t.compareTo(node.getData());
        if (result < 0) {
            node.setLeft(removeFromSubtree(node.getLeft(), t));
            return node;
        } else if (result > 0) {
            node.setRight(removeFromSubtree(node.getRight(), t));
            return node;
        } else { // result == 0
            if (node.getLeft() == null) {
                return node.getRight();
            } else if (node.getRight() == null) {
                return node.getLeft();
            } else { // neither child is null
                T predecessorValue = getHighestValue(node.getLeft());
                node.setLeft(removeRightmost(node.getLeft()));
                node.setData(predecessorValue);
                return node;
            }
        }
    }
    
    /**
     * Adds a BST Node to the current sub-tree rooted from {@code node} according to the value of its data
     * Defaults adding to the left if toAdd.getData() compares equal to one of the existing
     * @param node: root of the sub-tree
     * @param toAdd: node to be added to the tree
     * @return: node of the updated root of the tree, if any modifications occur.
     */
    protected BSTNode<T> addToSubtree(BSTNode<T> node, BSTNode<T> toAdd) {
        if (node == null) {
            return toAdd;
        }
        int result = toAdd.getData().compareTo(node.getData());
        if (result <= 0) {
            node.setLeft(addToSubtree(node.getLeft(), toAdd));
        } else {
            node.setRight(addToSubtree(node.getRight(), toAdd));
        }
        return node;
    }
    
    /**
     * Returns the depth of the sub-tree rooted from {@code node}
     * @param node: root of the sub-tree to measure
     * @param depth: variable passed for keeping track. Defaults to -1 when calling from outside.
     * @return: the depth of the sub-tree starting from {@code node}
     */
    private int heightHelper(BSTNode<T> node, int depth) {
        if (node == null) {
            return depth;
        }
        int leftHeight = this.heightHelper(node.getLeft(), depth + 1);
        int rightHeight = this.heightHelper(node.getRight(), depth + 1);
        return leftHeight > rightHeight? leftHeight : rightHeight;
    }
    
    /**
     * Helper for the equals method to compare the structure and content between 2 sub-trees
     * Precondition: neither of the nodes are null
     * @param node1: root of the first sub-tree
     * @param node2: root of the second sub-tree
     * @return: whether if the 2 sub-trees are equal in structure and content
     */
    boolean equalsHelper(BSTNode<T> node1, BSTNode<T> node2) {
        if (!node1.getData().equals(node2.getData())) {
            return false;
        }
        if (node1.getLeft() != null) {
            // in case that the .equals() method is not defined for null;
            if (node2.getLeft() == null) {
                return false;   // n1 has lc but n2 doesn't
            }
            if (node1.getRight() != null) {
                if (node2.getRight() == null) {
                    return false;   // n1 has rc but n2 doesn't
                }
                // n1 n2 both has lc and rc
                return (this.equalsHelper(node1.getLeft(), node2.getLeft())) && (this.equalsHelper(node1.getRight(), node2.getRight()));
            } else {
                if (node2.getRight() != null) {
                    return false;   // n1 doesn't have rc but n2 does
                }
                // n1 n2 both have lc but not rc
                return this.equalsHelper(node1.getLeft(), node2.getLeft());
            }
        } else {
            if (node1.getRight() != null) {
                if (node2.getRight() == null) {
                    return false;   // n1 has rc but n2 doesn't
                }
                // n1 n2 both has rc but not lc
                return this.equalsHelper(node1.getRight(), node2.getRight());
            } else {
                if (node2.getRight() != null) {
                    return false; // n1 doesn't have rc but n2 does
                }
                return true;    // neither n1 nor n2 has lc or rc
            }
        }
    }
    
    /**
     * I am afraid that java.lang.Math.log returns a floating point error of something like
     * log(1024)/log(2)=9.999999973 that results into a 9 when cast into an integer, so I'm defining my own bit-shift log algorithm here.
     * Precondition: num > 0
     * @param num: the number to be taken log2 of
     * @return: the floored log2 result
     */
    private int integerLog2(int num) {
        int log2 = 0;
        while (num > 1) {
            num >>= 1;
            log2 ++;
        }
        return log2;
    }
    /**
     * So why not?
     * Precondition: num >= 0
     * @param num: the number to calculate
     * @return: 2^num
     */
    private int pow2(int num) {
        return 1 << num;
    }
//    
//    /**
//     * Insert elements into the tree in such a manner that results in a balanced, flush-left tree.
//     * Runs in O(nlog(n))...
//     * hmmmm... that's not good.
//     * We can do better.
//     * Precondition: arr.size() >= 1
//     * @param arr: array of elements to be inserted into the tree.
//     * @param start: starting index to insert. default to 0
//     * @param end: index of the last element to insert + 1. default to arr.size()
//     */
//    private void insertOptimally(T[] arr, int start, int end) {
//        /*
//         * A null tree is already balanced so shouldn't enter this thing.
//         * The index of the top element is the size of the sub-tree from lc
//         * The size of the lc is the max number of elements of a mini-tree plus the number of "overflows" it accomodates
//         * height refers to real height, or height() + 1
//         * The height of the tree should be at most log2(size()) + 1
//         * The max number of elements of the mini-tree is 2^(height-2)-1
//         * The number of overflows is min(size() - (2^(total height-1)-1), 2^(height-2))
//         * omgomg, so many calculations, so prone to error.
//         * all that to calculate the starting index
//         */
//        if ((end - start) < 3) {
//            for(int i = end - 1; i >= start; i--) {
//                this.add(arr[i]);
//            }
//            return;
//        }
//        if ((end - start) == 3) {
//            this.add(arr[start + 1]);
//            this.add(arr[start]);
//            this.add(arr[start + 2]);
//            return;
//        }
//        /*
//        int totalheight = this.integerLog2(arr.length) + 1;
//        int totalnumofoverflows = arr.length - this.pow2(totalheight - 1) + 1;
//        int optimalHeight = this.integerLog2(end - start) + 1;
//        int miniminifulltree = this.pow2(optimalHeight - 2) - 1;
//        int maxnumofoverflows = this.pow2(optimalHeight - 2);
//        int numofoverflows = (maxnumofoverflows < totalnumofoverflows? maxnumofoverflows: totalnumofoverflows);
//        */
//        /* forget it, there is a better way
//         * because each subtree of an optimal tree is also optimal, so I can assume the same procedure for all of them, disregarding the effect of overflow
//         * for each segment of the arrays to be added into the tree, you are adding 
//         * Length = end - start = 1 + elements of the lc subtree + elments of the rc subtree
//         * Height = intlog2(Length) + 1
//         * complete size of tree with specified height is 2^(Height) - 1
//         * elements of the lc subtree > rc subtree unless tree is complete, where they are equal instead.
//         * there will be 3 scenarios:
//         * overflow less than half of final row:
//         *     * left subtree is incomplete, with a height of Height - 1
//         *     * right subtree is complete, with a height of Height - 2
//         * overflow more than half of final row:
//         *     * left subtree is complete with a height of Height - 1
//         *     * right subtree is incomplete, with a height of Height - 1
//         * overflow equals the capacity of final row:
//         *     * tree is complete
//         *     * lc and rc subtree both complete and has height of Height - 1
//        */
//        int l = end - start;
//        int h = this.integerLog2(l) + 1;
//        // most of the trees will be complete so perform this first
//        int max = this.pow2(h) - 1;
//        if (l == max) {
//            int half = start + (l - 1) / 2;
//            this.add(arr[half]);
//            this.insertOptimally(arr, start, half);
//            this.insertOptimally(arr, half + 1, end);
//            return;
//        }
//        int halfofmaximumsizeoffinalrow = this.pow2(h - 2); // technically this.pow2(h - 1) / 2, but whatever
//        if (l < (max - halfofmaximumsizeoffinalrow)) {
//            int rootindex = end - 1             // last elem index
//                    - (this.pow2(h - 2) - 1);   // size of the rc subtree
//            this.add(arr[rootindex]);
//            this.insertOptimally(arr, start, rootindex);
//            this.insertOptimally(arr, rootindex + 1, end);
//            return;
//        } else {
//            int rootindex = start
//                    + (this.pow2(h - 1) - 1); // size of the lc subtree;
//            this.add(arr[rootindex]);
//            this.insertOptimally(arr, start, rootindex);
//            this.insertOptimally(arr, rootindex + 1, end);
//            return;
//        }
//    }
    
    /**
     * Insert elements into the tree in such a manner that results in a balanced, flush-left tree.
     * Runs in O(n)
     * Precondition: arr.size() >= 1
     * @param arr: array of elements to be inserted into the tree.
     * @param start: starting index to insert. default to 0
     * @param end: index of the last element to insert + 1. default to arr.size()
     * @param subTreeRootNode: the root node of the subtree to be inserted
     * @param insertRight: false for left, true for right
     */
    @SuppressWarnings("unchecked")
    private void reallyInsertOptimally(Object[] arr, int start, int end, BSTNode<T> subTreeRootNode, boolean insertRight) {
        int rootindex = this.getRootIndex(start, end);
        if (rootindex == -1) {
            return;
        }
        BSTNode<T> newNode = new BSTNode<T>(((T)arr[rootindex]), null, null);
        if (subTreeRootNode == null) {
            this.root = newNode;
        } else if (insertRight) {
            subTreeRootNode.setRight(newNode);
        } else {
            subTreeRootNode.setLeft(newNode);            
        }
        this.reallyInsertOptimally(arr, start, rootindex, newNode, false);
        this.reallyInsertOptimally(arr, rootindex + 1, end, newNode, true);
        return;
    }
    
    /**
     * Calculates the root index to be inserted given the boundaries of the segment of a sorted list
     * @param start: start index of the values to be inserted
     * @param end: end index + 1 of the values to be inserted
     * @return: index of the root
     */
    private int getRootIndex(int start, int end) {
        int l = end - start;
        if (l == 0) {
            return -1;
        }
        if (l == 1) {
            return start;
        }
        if ((l == 2) || (l == 3)) {
            return start + 1;
        }
        int h = this.integerLog2(l) + 1;
        // most of the trees will be complete so perform this first
        int max = this.pow2(h) - 1;
        if (l == max) {
            return start + ((l - 1) / 2);
        }
        int halfofmaximumsizeoffinalrow = this.pow2(h - 2); // technically this.pow2(h - 1) / 2, but whatever
        if (l < max - halfofmaximumsizeoffinalrow) {
            return end - 1                      // last elem index
                    - (this.pow2(h - 2) - 1);   // size of the rc subtree
        }
        return start
                + (this.pow2(h - 1) - 1);       // size of the lc subtree;
    }
    
	// observers --------------------
	/**
	 * {@inheritDoc}
	 */
    public boolean isEmpty() {
        return root == null;
    }

    /**
     * {@inheritDoc}
     */
    public int size() {
        return subtreeSize(root);
    }
    
    /**
     * {@inheritDoc}
     */
    public boolean contains(T t) {
        if (t == null) {
            throw new NullPointerException("Parameter passed into the contains method is null.");
        }
        BSTNode<T> temp = this.root;
        if (temp == null) {
            return false;
        }
        boolean found = false;
        while (!found) {
            int compareResult = t.compareTo(temp.getData());
            if (compareResult == 0) {
                found = true;
            } else if (compareResult < 0) {
                if (temp.getLeft() == null) {
                    // zen of python: explicit is better than implicit
                    found = false;
                    break;
                }
                temp = temp.getLeft();
                continue;
            } else { // compareResult > 0
                if (temp.getRight() == null) {
                    found = false;
                    break;
                }
                temp = temp.getRight();
                continue;
            }
        }
        return found;
    }

    /**
     * {@inheritDoc}
     * Precondition: comparedTo() method is consistent with equals() method
     */
    public T get(T t) {
        if (t == null) {
            throw new NullPointerException("Parameter passed into the get method is null.");
        }
        BSTNode<T> temp = this.root;
        if (temp == null) {
            return null;
        }
        T elem = null;
        while (elem == null) {
            int compareResult = t.compareTo(temp.getData());
            if (compareResult == 0) {
                elem = temp.getData();
                break;
            } else if (compareResult < 0) {
                if (temp.getLeft() == null) {
                    // zen of python: explicit is better than implicit
                    elem = null;
                    break;
                }
                temp = temp.getLeft();
                continue;
            } else { // compareResult > 0
                if (temp.getRight() == null) {
                    elem = null;
                    break;
                }
                temp = temp.getRight();
                continue;
            }
        }
        return elem;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T getMinimum() {
        if (this.root == null) {
            return null;
        }
        BSTNode<T> temp = this.root;
        while (temp.getLeft() != null) {
            temp = temp.getLeft();
        }
        return temp.getData();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public T getMaximum() {
        if (this.root == null) {
            return null;
        }
        BSTNode<T> temp = this.root;
        while (temp.getRight() != null) {
            temp = temp.getRight();
        }
        return temp.getData();
    }

    /**
     * {@inheritDoc}
     * This method assumes that a tree of 1 level is of height 0, and a tree of 2 levels is of height 1, etc.
     * Kind of counter-intuitive.
     */
    @Override
    public int height() {
        return this.heightHelper(this.root, -1);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(BSTInterface<T> other) {
        if (other == null) {
            throw new NullPointerException("Parameter passed into equals() method is null.");
        }
        if (this.root == null) {
            if (other.getRoot() == null) {
                return true;
            }
            return false;
        }
        if (other.getRoot() == null) {
            return false;
        }
        return this.equalsHelper(this.root, other.getRoot());
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean sameValues(BSTInterface<T> other) {
        if (other == null) {
            throw new NullPointerException("Parameter passed into method sameValues() is null.");
        }
        T temp1, temp2;
        Iterator<T> q1 = this.inorderIterator();
        Iterator<T> q2 = other.inorderIterator();
        while (q1.hasNext()) {
            if (!q2.hasNext()) {
                return false;
            }
            temp1 = q1.next();
            temp2 = q2.next();
            if (!temp1.equals(temp2)) {
                return false;
            }
        }
        if (q2.hasNext()) {
            return false;
        }
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isBalanced() {
        if (this.root == null) {
            return true;
        }
        // returns that (the maximum number of elems can be held by BST of this height - 1) < num of elems
        // because this.height() is the real height - 1, so, duh
        // stupid definitions
        return pow2(this.height()) - 1 < this.size();
    }

    @Override
    public BSTNode<T> getRoot() {
        // DO NOT MODIFY
        return root;
    }

    public static <T extends Comparable<T>> String toDotFormat(BSTNode<T> root) {
        // header
        int count = 0;
        String dot = "digraph G { \n";
        dot += "graph [ordering=\"out\"]; \n";
        // iterative traversal
        Queue<BSTNode<T>> queue = new LinkedList<BSTNode<T>>();
        queue.add(root);
        BSTNode<T> cursor;
        while (!queue.isEmpty()) {
            cursor = queue.remove();
            if (cursor.getLeft() != null) {
                // add edge from cursor to left child
                dot += cursor.getData().toString() + " -> "
                        + cursor.getLeft().getData().toString() + ";\n";
                queue.add(cursor.getLeft());
            } else {
                // add dummy node
                dot += "node" + count + " [shape=point];\n";
                dot += cursor.getData().toString() + " -> " + "node" + count
                        + ";\n";
                count++;
            }
            if (cursor.getRight() != null) {
                // add edge from cursor to right child
                dot += cursor.getData().toString() + " -> "
                        + cursor.getRight().getData().toString() + ";\n";
                queue.add(cursor.getRight());
            } else {
                // add dummy node
                dot += "node" + count + " [shape=point];\n";
                dot += cursor.getData().toString() + " -> " + "node" + count
                        + ";\n";
                count++;
            }

        }
        dot += "};";
        return dot;
    }
    
	// transformers --------------------
    /**
     * {@inheritDoc}
     * Not optimized. Finds T twice.
     */
    public boolean remove(T t) {
        if (t == null) {
            throw new NullPointerException();
        }
        boolean result = this.contains(t);
        if (result) {
            root = this.removeFromSubtree(root, t);
        }
        return result;
    }
    
    /**
     * {@inheritDoc}
     * Defaults to adding to the right if the element compares equal to an existing
     */
    public void add(T t) {
        if (t == null) {
            throw new NullPointerException();
        }
        root = addToSubtree(root, new BSTNode<T>(t, null, null));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void balance() {
        if (this.isBalanced()) {   // O(1)
            return;
        }
        Object[] arrayForm = new Object[this.size()];  // O(size())
        Iterator<T> tempIterator = this.inorderIterator(); // O(size())
        for (int i = 0; i < this.size(); i++) {   // O(size())
            arrayForm[i] = tempIterator.next();
        }
        tempIterator = null;
        this.root = null;
        this.reallyInsertOptimally(arrayForm, 0, arrayForm.length, null, false);
        return;
    }
    
    // iterators --------------------
    
    /**
     * {@inheritDoc}
     */
    public Iterator<T> preorderIterator() {
        Queue<T> queue = new LinkedList<T>();
        preorderTraverse(queue, root);
        return queue.iterator();
    }

    /**
     * {@inheritDoc}
     * The nature of the BST makes this ordering ordered by size
     */
    public Iterator<T> inorderIterator() {
        Queue<T> queue = new LinkedList<T>();
        inorderTraverse(queue, root);
        return queue.iterator();
    }
    
    public Iterator<T> postorderIterator() {
        Queue<T> queue = new LinkedList<T>();
        postorderTraverse(queue, root);
        return queue.iterator();
    }
    
    // iterator helpers --------------------
    /**
     * Helper method that traverses the sub-tree rooted from {@code node} and adds element to the queue in in-order order
     * @param queue: the queue to add value into
     * @param node: root of the sub-tree to traverse
     */
    private void inorderTraverse(Queue<T> queue, BSTNode<T> node) {
        if (node != null) {
            inorderTraverse(queue, node.getLeft());
            queue.add(node.getData());
            inorderTraverse(queue, node.getRight());
        }
    }
    
    /**
     * Helper method that traverses the sub-tree rooted from {@code node} and adds element to the queue in pre-order order
     * @param queue: the queue to add value into
     * @param node: root of the sub-tree to traverse
     */
    private void preorderTraverse(Queue<T> queue, BSTNode<T> node) {
        if (node != null) {
            queue.add(node.getData());
            preorderTraverse(queue, node.getLeft());
            preorderTraverse(queue, node.getRight());
        }
    }
    
    /**
     * Helper method that traverses the sub-tree rooted from {@code node} and adds element to the queue in post-order order
     * @param queue: the queue to add value into
     * @param node: root of the sub-tree to traverse
     */
    private void postorderTraverse(Queue<T> queue, BSTNode<T> node) {
        if (node != null) {
            postorderTraverse(queue, node.getLeft());
            postorderTraverse(queue, node.getRight());
            queue.add(node.getData());
        }
    }

	// driver --------------------
	public static void main(String[] args) {
		for (String r : new String[] { "a", "b", "c", "d", "e", "f", "g" }) {
			BSTInterface<String> tree = new BinarySearchTree<String>();
			for (String s : new String[] { "d", "b", "a", "c", "f", "e", "g" }) {
				tree.add(s);
			}
			Iterator<String> iterator = tree.inorderIterator();
			while (iterator.hasNext()) {
				System.out.print(iterator.next());
			}
			System.out.println();
			iterator = tree.preorderIterator();
			while (iterator.hasNext()) {
				System.out.print(iterator.next());
			}
			System.out.println();
			iterator = tree.postorderIterator();
			while (iterator.hasNext()) {
				System.out.print(iterator.next());
			}
			System.out.println();

			System.out.println(tree.remove(r));

			iterator = tree.inorderIterator();
			while (iterator.hasNext()) {
				System.out.print(iterator.next());
			}
			System.out.println();
		}

		BSTInterface<String> tree = new BinarySearchTree<String>();
		for (String r : new String[] { "a", "b", "c", "d", "e", "f", "g" }) {
			tree.add(r);
		}
		System.out.println(tree.size());
		System.out.println(tree.height());
		System.out.println(tree.isBalanced());
		tree.balance();
		System.out.println(tree.size());
		System.out.println(tree.height());
		System.out.println(tree.isBalanced());
	}
}