// implemented by SQ in a hurry on 07/08/2018
// a burning bus runs for now.

package structures;

import java.lang.Math;

public class ScapegoatTree<T extends Comparable<T>> extends
		BinarySearchTree<T> {
   
    static final double THREE_HALVES = 3./2.;
    static final double TWO_THIRDS = 2./3.;
    
	public int upperBound;
	private BSTNode<T> scapegoat, scapegoatparent;
	
	private double logthreehalf(double num) {
	    return Math.log(num) / Math.log(THREE_HALVES);
	}
	
	private void findScapegoat(BSTNode<T> node, T data, boolean initialized) {
	    boolean right;
	    if (!initialized) {
	        this.scapegoat = null;
	        this.scapegoatparent = null;
	        initialized = true;
	    }
	    if (data.compareTo(node.getData()) > 0) {
	        right = true;
	        this.findScapegoat(node.getRight(), data, initialized);
	    } else {
	        right = false;
	        if (node.getLeft() != null) {
	            this.findScapegoat(node.getLeft(), data, initialized);
	        }
	    }
	    if (this.scapegoat != null) {
	        if (this.scapegoatparent == null) {
	            this.scapegoatparent = node;
	        }
	        return;
	    }
	    if (right) {
	        if ((((double)super.subtreeSize(node.getRight())) / ((double)super.subtreeSize(node))) > TWO_THIRDS) {
	            this.scapegoat = node;
	        }
	    } else {
            if ((((double)super.subtreeSize(node.getLeft())) / ((double)super.subtreeSize(node))) > TWO_THIRDS) {
                this.scapegoat = node;
            }
	    }
	    return;
	}
	
	public ScapegoatTree() {
        super();
	    this.upperBound = 0;
	}
	
	@Override
	public void add(T t) {
	    boolean right = false;
	    this.upperBound ++;
	    super.add(t);
	    if (this.height() <= this.logthreehalf(this.upperBound)) {
	        return;
	    }
	    this.findScapegoat(this.root, t, false);
	    BinarySearchTree<T> temptree = new BinarySearchTree<T>();
	    if (this.scapegoatparent != null) {
	        if (this.scapegoatparent.getRight() == this.scapegoat) {
	            right = true;
	        } else {
	            right = false;
	        }
	    }
	    temptree.root = this.scapegoat;
	    temptree.balance();
	    if (this.scapegoatparent == null) {
	        this.root = temptree.root;
	    } else {
    	    if (right) {
    	        this.scapegoatparent.setRight(temptree.root);
    	    } else {
    	        this.scapegoatparent.setLeft(temptree.root);
    	    }
	    }
	    return;
	}
	
	@Override
	public boolean remove(T element) {
		boolean removed = super.remove(element);
		if (removed) {
		    if (this.upperBound > (2 * super.size())) {
		        super.balance();
		        this.upperBound = super.size();
		    }
		}
		return removed;
	}
}
