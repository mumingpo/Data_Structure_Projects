package structures;

import static org.junit.Assert.*;
import java.util.Random;

import org.junit.Test;

import org.junit.Before;


public class SGT_Tests_Steven {

    static int IDS = 0;
    class Circle implements Comparable<Circle> {
        private int id;
        private int radius;
        private String color;
        public Circle(int r, String c) {
            this.radius = r;
            this.color = c;
            this.id = IDS;
            IDS ++;
        }
        
        @Override
        public boolean equals(Object c) {
            return (this.radius == ((Circle)c).getRadius());
        }
        
        @Override
        public int compareTo(Circle c) {
            return (this.radius - c.getRadius());
        }
        
        public String getColor() {
            return this.color;
        }
        
        public int getRadius() {
            return this.radius;
        }
        
        public String toString() {
            return "\"" + this.radius + "<" + this.id + ">\"";
            //return ("Circle_" + this.id + "_" + this.radius + "_" + this.color);
        }
    }
    
    ScapegoatTree<Circle> test;
    Random rng = new Random();
    
    private double logthreehalves(double num) {
        return java.lang.Math.log(num)/java.lang.Math.log(1.5);
    }
    
    @Before
    public void setup() {
    }
    
    @Test
    public void test() {
        java.util.ArrayList<Circle> tobedeleted;
        java.util.Iterator<Circle> it;
        for (int i = 0; i < 10000000; i++) {
        //int i = 0;
        //while (true) {
            this.test = new ScapegoatTree<Circle>();
            tobedeleted = new java.util.ArrayList<Circle>();
            for (int j = 0; j < rng.nextInt(200) + 1; j++) {
                Circle c = new Circle(rng.nextInt(100), "");
                this.test.add(c);
                if (rng.nextDouble() < 0.05 && this.test.size() > tobedeleted.size() + 1) {
                    tobedeleted.add(c);
                }
            }
            java.util.Collections.shuffle(tobedeleted);
            it = tobedeleted.iterator();
            while (it.hasNext()) {
                this.test.remove(it.next());
            }
            //System.out.println(BinarySearchTree.toDotFormat(this.test.root));
            if (this.test.size() < this.test.upperBound/2 || this.test.size() > this.test.upperBound) {
                fail("The test  case " + i 
                        + " has a size of " + this.test.size() 
                        + " and an upperbound of " + this.test.upperBound
                        + "\nThe structure is:\n" + ScapegoatTree.toDotFormat(this.test.getRoot()));
            }
            if (this.test.height() > this.logthreehalves(this.test.upperBound)){
                fail("The test case " + i + " has a height of " + this.test.height() 
                + " and a log_3/2(upperBound) of " + this.logthreehalves(this.test.upperBound) 
                + "\nThe structure of test i is\n" + BinarySearchTree.toDotFormat(this.test.root));
            }
            it = this.test.inorderIterator();
            Circle prev = it.next();
            while (it.hasNext()) {
                Circle c = it.next();
                if (prev.compareTo(c) > 0) {
                    fail("The structure for test " + i 
                            + " is not a binary search tree. The structure is:\n" + BinarySearchTree.toDotFormat(this.test.root));
                }
            }
            //i ++;
            //if (i % 1000000 == 0) {
            //    System.out.println(i + " tests completed.");
            //}
        }
    }

}
