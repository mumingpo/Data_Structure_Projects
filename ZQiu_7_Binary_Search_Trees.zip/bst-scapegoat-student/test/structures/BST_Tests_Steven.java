// created by SQ on 07/08/2018

package structures;

import static org.junit.Assert.*;
import java.util.Random;

import org.junit.Test;

import structures.SGT_Tests_Steven.Circle;

import org.junit.Before;

public class BST_Tests_Steven {
    
    private BinarySearchTree<Circle> empty, one, onedifferent, five, fiveidentical, seven, sevenidenticaldiffstructure, large;
    static int IDS = 0;
    class Circle implements Comparable<Circle> {
        private int id;
        private int radius;
        private String color;
        public Circle(int r, String c) {
            this.radius = r;
            this.color = c;
            this.id = IDS;
            IDS ++;
        }
        
        @Override
        public boolean equals(Object c) {
            return (this.radius == ((Circle)c).getRadius());
        }
        
        @Override
        public int compareTo(Circle c) {
            return (this.radius - c.getRadius());
        }
        
        public String getColor() {
            return this.color;
        }
        
        public int getRadius() {
            return this.radius;
        }
        
        public String toString() {
            return "\"" + this.radius + "<" + this.id + ">\"";
            //return ("Circle_" + this.id + "_" + this.radius + "_" + this.color);
        }
    }
    
    private int pow2(int num) {
        return 1 << num;
    }
    
    @Before
    public void setup() {
        this.empty = new BinarySearchTree<Circle>();
        this.one = new BinarySearchTree<Circle>();
        this.onedifferent = new BinarySearchTree<Circle>();
        this.five = new BinarySearchTree<Circle>();
        this.fiveidentical = new BinarySearchTree<Circle>();
        this.seven = new BinarySearchTree<Circle>();
        this.sevenidenticaldiffstructure = new BinarySearchTree<Circle>();
        this.large = new BinarySearchTree<Circle>();

        this.one.add(new Circle(3, "Blue"));
        
        this.onedifferent.add(new Circle(0, "Blue"));
        
        this.five.add(new Circle(1, "Green"));
        this.fiveidentical.add(new Circle(1, "Orange"));
        this.five.add(new Circle(4, "Brown"));
        this.fiveidentical.add(new Circle(4, "Yellow"));
        this.five.add(new Circle(1, "Magenta"));
        this.fiveidentical.add(new Circle(1, "Cyan"));
        this.five.add(new Circle(5, "Purple"));
        this.fiveidentical.add(new Circle(5, "Red"));
        this.five.add(new Circle(9, "Pink"));
        this.fiveidentical.add(new Circle(9, "Navy"));

        this.seven.add(new Circle(2, "White"));
        this.seven.add(new Circle(6, "Transparent"));
        this.seven.add(new Circle(5, "Gray"));
        this.seven.add(new Circle(3, "Gold"));
        this.seven.add(new Circle(5, "Azure"));
        this.seven.add(new Circle(8, "Cobalt"));
        this.seven.add(new Circle(9, "Indigo"));

        this.sevenidenticaldiffstructure.add(new Circle(5, "Gray"));
        this.sevenidenticaldiffstructure.add(new Circle(3, "I don't care"));
        this.sevenidenticaldiffstructure.add(new Circle(8, "any more"));
        this.sevenidenticaldiffstructure.add(new Circle(2, "does"));
        this.sevenidenticaldiffstructure.add(new Circle(5, "not"));
        this.sevenidenticaldiffstructure.add(new Circle(6, "matter"));
        this.sevenidenticaldiffstructure.add(new Circle(9, "anyways"));
        
        Random rng = new Random();
        for (int i = 0; i < 10000; i++) {
            this.large.add(new Circle(rng.nextInt(5000), "Chicken!"));
        }
        
        return;
    }
    
    // constructors --------------------
    @Test (timeout = 500)
    public void testConstructor() {
        new BinarySearchTree<Circle>();
    }
    
    // observers --------------------
    @Test (timeout = 500)
    public void testIsEmpty() {
        assertTrue(this.empty.isEmpty());
        assertFalse(this.one.isEmpty());
    }

    @Test (timeout = 500)
    public void testSize() {
        assertEquals(0, this.empty.size());
        assertEquals(1, this.one.size());
        assertEquals(5, this.five.size());
        assertEquals(7, this.seven.size());
        assertEquals(10000, this.large.size());
    }
    
    @Test (timeout = 500) 
    public void testContains() {
        Circle temp = new Circle(3, "Mango");
        assertFalse(this.empty.contains(temp));
        assertTrue(this.one.contains(temp));
        assertFalse(this.five.contains(temp));
        assertTrue(this.seven.contains(temp));
    }
    
    @Test (timeout = 500, expected = NullPointerException.class)
    public void testContainsException() {
        this.one.contains(null);
    }

    
    @Test (timeout = 500) 
    public void testGet() {
        Circle temp = new Circle(3, "Mango");
        assertNull(this.empty.get(temp));
        assertEquals(temp, this.one.get(temp));
        assertNull(this.five.get(temp));
        assertEquals(temp, this.seven.get(temp));
        
        assertEquals("Blue", this.one.get(temp).getColor());
    }
    
    @Test (timeout = 500, expected = NullPointerException.class)
    public void testGetException() {
        this.one.get(null);
    }
    
    @Test (timeout = 500)
    public void testGetMinimum() {
        assertNull(this.empty.getMinimum());
        assertEquals(3, this.one.getMinimum().getRadius());
        assertEquals(1, this.five.getMinimum().getRadius());
        assertEquals(2, this.seven.getMinimum().getRadius());
    }
    
    @Test (timeout = 500)
    public void testGetMaximum() {
        assertNull(this.empty.getMaximum());
        assertEquals(3, this.one.getMaximum().getRadius());
        assertEquals(9, this.five.getMaximum().getRadius());
        assertEquals(9, this.seven.getMaximum().getRadius());
    }
    
    @Test (timeout = 500)
    public void testHeight() {
        /* This test is implementation specific, and may not behave the same for all codes
         * if your code behaves differently, you should write your own tests.
         */
        assertEquals(-1, this.empty.height());
        assertEquals(0, this.one.height());
        assertEquals(3, this.five.height());
        assertEquals(4, this.seven.height());
    }
    
    @Test (timeout = 500)
    public void testEquals() {
        /* This test is implementation specific, and may not behave the same for all codes
         * if your code behaves differently, you should write your own tests.
         */
        assertFalse(this.empty.equals(this.one));
        assertFalse(this.one.equals(this.empty));
        assertTrue(this.empty.equals(this.empty));
        assertTrue(this.one.equals(this.one));
        assertTrue(this.five.equals(this.fiveidentical));
        assertFalse(this.seven.equals(this.sevenidenticaldiffstructure));
    }
    
    @Test (timeout = 500, expected = NullPointerException.class)
    public void testEqualsException() {
        this.one.equals(null);
    }
    
    @Test (timeout = 500)
    public void testSameValues() {
        assertFalse(this.empty.sameValues(this.one));
        assertFalse(this.one.sameValues(this.empty));
        assertTrue(this.empty.sameValues(this.empty));
        assertTrue(this.one.sameValues(this.one));
        assertTrue(this.five.sameValues(this.fiveidentical));
        assertTrue(this.seven.sameValues(this.sevenidenticaldiffstructure));
    }
    
    @Test (timeout = 500, expected = NullPointerException.class)
    public void testSameValuesException() {
        this.one.sameValues(null);
    }
    
    @Test (timeout = 500)
    public void testIsBalanced() {
        /* This test is implementation specific, and may not behave the same for all codes
         * if your code behaves differently, you should write your own tests.
         */
        assertTrue(this.empty.isBalanced());
        assertTrue(this.one.isBalanced());
        assertFalse(this.five.isBalanced());
        assertFalse(this.seven.isBalanced());
        assertTrue(this.sevenidenticaldiffstructure.isBalanced());
    }

    // transformers --------------------
    @Test (timeout = 500)
    public void testRemove() {
        Circle temp = new Circle(3, "Mango");
        assertFalse(this.empty.remove(temp));
        assertEquals(0, this.empty.size());
        assertTrue(this.one.remove(temp));
        assertEquals(0, this.one.size());
        assertFalse(this.five.remove(temp));
        assertEquals(5, this.five.size());
        assertTrue(this.seven.remove(temp));
        assertEquals(6, this.seven.size());
        assertFalse(this.seven.remove(temp));
    }
    
    @Test (timeout = 500, expected = NullPointerException.class)
    public void testRemoveException() {
        this.one.remove(null);
    }
    
    @Test (timeout = 500)
    public void testAdd() {
        Circle temp = new Circle(3, "Mango");
        this.empty.add(temp);
        assertEquals(1, this.empty.size());
        this.one.add(temp);
        assertEquals(2, this.one.size());
        this.large.add(temp);
        assertEquals(10001, this.large.size());
    }
    
    @Test (timeout = 500, expected = NullPointerException.class)
    public void testAddException() {
        this.one.add(null);
    }
    
    @Test (timeout = 5000)
    public void testBalance() {
        this.empty.balance();
        assertTrue(this.empty.isBalanced());
        this.one.balance();
        assertTrue(this.one.isBalanced());
        this.five.balance();
        assertTrue(this.five.isBalanced());
        this.seven.balance();
        assertTrue(this.seven.isBalanced());
        java.util.Iterator<Circle> it = this.seven.inorderIterator();
        assertEquals(2, it.next().getRadius());
        assertEquals(3, it.next().getRadius());
        assertEquals(5, it.next().getRadius());
        assertEquals(5, it.next().getRadius());
        assertEquals(6, it.next().getRadius());
        assertEquals(8, it.next().getRadius());
        assertEquals(9, it.next().getRadius());
        assertFalse(it.hasNext());
        /* if you timeout on this test, your algorithm may not be efficient enough
         * this is not wrong, but should ring a bell on creating a more efficient design next time
         * if you can't get pass this test, feel free just comment it out, or eliminate the timeout modifier after @Test.
         * for comparison, the author's code is O(n) but heavy in terms of overhead
         * and runs this test in 0.012 seconds on a laptop.
         */
        this.large.balance();
        assertTrue(this.large.isBalanced());
    }

    // iterators --------------------
    @Test (timeout = 500)
    public void testPreorderIterator() {
        java.util.Iterator<Circle> it = this.seven.preorderIterator();
        assertEquals(2, it.next().getRadius());
        assertEquals(6, it.next().getRadius());
        assertEquals(5, it.next().getRadius());
        assertEquals(3, it.next().getRadius());
        assertEquals(5, it.next().getRadius());
        assertEquals(8, it.next().getRadius());
        assertEquals(9, it.next().getRadius());
        assertFalse(it.hasNext());
    }

    @Test (timeout = 500)
    public void testInorderIterator() {
        /* This test is implementation specific, and may not behave the same for all codes
         * if your code behaves differently, you should write your own tests.
         */
        java.util.Iterator<Circle> it = this.seven.inorderIterator();
        assertEquals(2, it.next().getRadius());
        assertEquals(3, it.next().getRadius());
        assertEquals(5, it.next().getRadius());
        assertEquals(5, it.next().getRadius());
        assertEquals(6, it.next().getRadius());
        assertEquals(8, it.next().getRadius());
        assertEquals(9, it.next().getRadius());
        assertFalse(it.hasNext());
    }

    @Test (timeout = 500)
    public void testPostorderIterator() {
        /* This test is implementation specific, and may not behave the same for all codes
         * if your code behaves differently, you should write your own tests.
         */
        java.util.Iterator<Circle> it = this.seven.postorderIterator();
        assertEquals(5, it.next().getRadius());
        assertEquals(3, it.next().getRadius());
        assertEquals(5, it.next().getRadius());
        assertEquals(9, it.next().getRadius());
        assertEquals(8, it.next().getRadius());
        assertEquals(6, it.next().getRadius());
        assertEquals(2, it.next().getRadius());
        assertFalse(it.hasNext());
    }
    
    @Test
    public void brutalTotalTesting() {
        Random rng = new Random();
        java.util.ArrayList<Circle> toberemoved;
        java.util.Iterator<Circle> it, it2;
        for (int i = 0; i < 10000; i++) {
            int originalsize = rng.nextInt(200) + 1;
            this.large = new BinarySearchTree<Circle>();
            toberemoved = new java.util.ArrayList<Circle>();
            for (int j = 0; j < originalsize; j++) {
                Circle c = new Circle(rng.nextInt(100), "");
                this.large.add(c);
                if (rng.nextDouble() < 0.05 && this.large.size() > toberemoved.size() + 1) {
                    toberemoved.add(c);
                }
            }
            java.util.Collections.shuffle(toberemoved);
            it = toberemoved.iterator();
            while (it.hasNext()) {
                this.large.remove(it.next());
            }
            assertEquals("Remove method did not work correctly", originalsize, toberemoved.size() + this.large.size());
            it = this.large.inorderIterator();
            this.large.balance();
            it2 = this.large.inorderIterator();
            if (this.pow2(this.large.height()) > this.large.size()) {
                fail("Test case " + i + " didn't pass. The structure is " + BinarySearchTree.toDotFormat(this.large.getRoot()));
            }
            while (it.hasNext()) {
                assertTrue(it2.hasNext());
                assertEquals(it.next(), it2.next());
            }
        }
    }
}
