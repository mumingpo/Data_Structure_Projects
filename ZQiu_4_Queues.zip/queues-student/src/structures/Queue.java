// implemented by SQ on 06/13/2018
package structures;

import java.util.NoSuchElementException;

public class Queue<T> implements UnboundedQueueInterface<T> {
    
    // implemented by SQ on 06/13
    protected Node<T> front, back;
    private int size;
    /**
     * {@inheritDoc}
     */
	public Queue() {		
	    this.front = null;
	    this.back = null;
	    this.size = 0;
	    return;
    }

    // implemented by SQ on 06/13
    /**
     * {@inheritDoc}
     */
	public Queue(Queue<T> other) {
	    // enqueue operation keeps track of size so we don't need to worry about it
	    this.size = 0;
	    if (other.size == 0) {
	        this.front = null;
	        this.back = null;
	    } else {
	        Node<T> temp = other.front;
    	    while (temp != null) {
    	        this.enqueue(temp.getData());
    	        temp = temp.getNext();
    	    }
	    }
	    return;
	}

    // implemented by SQ on 06/13
    /**
     * {@inheritDoc}
     */
	@Override
	public boolean isEmpty() {
        return (this.size == 0);
	}

    // implemented by SQ on 06/13
    /**
     * {@inheritDoc}
     */
	@Override
	public int size() {
        return this.size;
	}

    // implemented by SQ on 06/13
    /**
     * {@inheritDoc}
     */
	@Override
	public void enqueue(T element) {
        Node<T> temp = new Node<T>(element);
        if (this.isEmpty()) {
            this.front = temp;
            this.back = temp;
        } else {
            this.back.setNext(temp);
            this.back = temp;
        }
        this.size ++;
        return;
	}

    // implemented by SQ on 06/13
    /**
     * {@inheritDoc}
     */
	@Override
	public T dequeue() throws NoSuchElementException {
        if (this.isEmpty()) {
            throw new NoSuchElementException("Attempt to dequeue from an empty queue.");
        }
        T data = this.front.getData();
        this.front = this.front.getNext();
        this.size --;
        return data;
	}

    // implemented by SQ on 06/13
    /**
     * {@inheritDoc}
     */
	@Override
	public T peek() throws NoSuchElementException {
        if (this.isEmpty()) {
            throw new NoSuchElementException("Attempt to access front element of an empty queue.");
        }
        return this.front.getData();
	}
	
	// implemented by SQ on 06/13
    /**
     * {@inheritDoc}
     */
	@Override
	public UnboundedQueueInterface<T> reversed() {
        /* ALGORITHMS!
         * An algorithm that is O(N), do not involve recursion, and use only singly-linked list using the steps below:
         * 
         * 1) make the nodes protected instead of private within the queue class for easier manipulation
         * 2) copy the queue
         * 3) special cases for small queues
         * 4) set temporary node reference tempBefore to element 0, tempAfter to element 2. Set front to element 1, end to element 0
         * 5) perform the following subroutine until tempAfter is null:
         * 5.1) set front.next to tempBefore.
         * 5.2) set tempBefore to front
         * 5.3) set front to tempAfter
         * 5.4) set tempAfter to tempAfter.next
         * 6) set front.next to tempBefore, set end.next to null
         * 7) return queue.
         * 
         * This is several times less efficient than the recursive implementation, albeit on the same complexity scale. 
         * However, the additional computational resource is justified because the queue need to be unbounded and not limited by an unpredictable maximum recursion limit (in-place algorithm).
         */
	    Queue<T> reversedQueue = new Queue<T>(this);
	    if (reversedQueue.size < 2) {
	        return reversedQueue;
	    }
	    reversedQueue.back = reversedQueue.front;
	    Node<T> tempBefore = reversedQueue.front;
	    reversedQueue.front = reversedQueue.front.getNext();
	    Node<T> tempAfter = reversedQueue.front.getNext();
	    while (tempAfter != null) {
	        reversedQueue.front.setNext(tempBefore);
	        tempBefore = reversedQueue.front;
	        reversedQueue.front = tempAfter;
	        tempAfter = tempAfter.getNext();
	    }
	    reversedQueue.front.setNext(tempBefore);
	    reversedQueue.back.setNext(null);
	    return reversedQueue;
	}
}
