// implemented by SQ on 06/13
package filesystem;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.NoSuchElementException;
import structures.Queue;

/**
 * An iterator to perform a level order traversal of part of a 
 * filesystem. A level-order traversal is equivalent to a breadth-
 * first search.
 * 
 * @author liberato
 *
 */
public class LevelOrderIterator extends FileIterator<File> {
	
    private Queue<File> processedFile;
	/**
	 * Instantiate a new LevelOrderIterator, rooted at the rootNode.
	 * @param rootNode
	 * @throws FileNotFoundException if the rootNode does not exist
	 */
	public LevelOrderIterator(File rootNode) throws FileNotFoundException {
	    if (!rootNode.exists()) {
	        throw new FileNotFoundException("Specified file \"" + rootNode.toString() + "\" does not exist.");
	    }
	    Queue<File> toBeProcessed = new Queue<File>();
	    Queue<File> processed = new Queue<File>();
	    toBeProcessed.enqueue(rootNode);
	    while (!toBeProcessed.isEmpty()) {
	        File temp = toBeProcessed.dequeue();
	        if (temp.isDirectory()) {
	            File [] containedFiles = temp.listFiles();
	            Arrays.sort(containedFiles);
	            for (File f: containedFiles) {
	                toBeProcessed.enqueue(f);
	            };
	        }
	        processed.enqueue(temp);
	    }
	    this.processedFile = processed;
	    return;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean hasNext() {
	    return (!this.processedFile.isEmpty());
	}
    
    /**
     * {@inheritDoc}
     */
	@Override
	public File next() throws NoSuchElementException {
	    if (!this.hasNext()) {
	        throw new NoSuchElementException("There is no more file to iterate through.");
	    }
        return this.processedFile.dequeue();
	}

	@Override
	public void remove() {
		// Leave this one alone.
		throw new UnsupportedOperationException();		
	}

}
