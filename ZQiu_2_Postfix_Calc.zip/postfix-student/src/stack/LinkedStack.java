// edited by SQ on 06/03/2018
package stack;

//implemented by SQ on 06/03/2018
/**
 * A {@link LinkedStack} is a stack that is implemented using a Linked List structure
 * to allow for unbounded size.
 *
 * @param <T> the elements stored in the stack
 */
public class LinkedStack<T> implements StackInterface<T> {
	
	private LLNode<T> topOfTheStack;
	private int numOfElems; // not required, but makes size() O(1) instead of O(N) at neglectable cost
	
	/**
	 * Initializing an empty stack
	 */
	public LinkedStack(){
		this.topOfTheStack = null;
		this.numOfElems = 0;
		return;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public T pop() throws StackUnderflowException {
		if (this.isEmpty()) {
			throw new StackUnderflowException("Pop operation attempted on empty stack.");
		}
		T temp = this.topOfTheStack.getData();
		this.topOfTheStack = this.topOfTheStack.getNext();
		numOfElems --;
		return temp;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public T top() throws StackUnderflowException {
		if (this.isEmpty()) {
			throw new StackUnderflowException("Top operation attempted on empty stack.");
		}
		return this.topOfTheStack.getData();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isEmpty() {
		if (this.topOfTheStack == null) {
			return true;
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int size() {
		return this.numOfElems;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void push(T elem) {
		LLNode<T> temp = new LLNode<T> (elem);
		temp.setNext(this.topOfTheStack);
		this.topOfTheStack = temp;
		this.numOfElems ++;
		return;
	}

}
