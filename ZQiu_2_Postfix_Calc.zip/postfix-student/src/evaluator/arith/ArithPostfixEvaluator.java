// edited by SQ on 06/03/2018
package evaluator.arith;

import language.Operand;
import language.Operator;
import parser.IllegalPostfixExpressionException;
import parser.PostfixParser.Type;
import parser.Token;
import parser.arith.ArithPostfixParser;
import stack.LinkedStack;
import stack.StackInterface;
import evaluator.PostfixEvaluator;

/**
 * An {@link ArithPostfixEvaluator} is a postfix evaluator over simple arithmetic expressions.
 *
 */
public class ArithPostfixEvaluator implements PostfixEvaluator<Integer> {

	private final StackInterface<Operand<Integer>> stack;
	
	// implemented by SQ on 06/03
	/**
	 * Constructs an {@link ArithPostfixEvaluator}
	 */
	public ArithPostfixEvaluator(){
        this.stack = new LinkedStack<Operand<Integer>>();
	}
	
	// implemented by SQ on 06/03
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Integer evaluate(String expr) throws IllegalPostfixExpressionException {
		ArithPostfixParser parser = new ArithPostfixParser(expr);
		for (Token<Integer> token : parser) {
			Type type = token.getType();
			switch(type){ 
			case OPERAND:
				stack.push(token.getOperand());
				break;
			case OPERATOR:
            	Operator<Integer> tempOperator = token.getOperator();
            	if (tempOperator.getNumberOfArguments() == 1) {
            		if (stack.size() < 1) {
            			throw new IllegalPostfixExpressionException("There are too many operators for the operands given.");
            		}
            		tempOperator.setOperand(0, stack.pop());
            	} else if (tempOperator.getNumberOfArguments() == 2) {
            		if (stack.size() < 2) {
            			throw new IllegalPostfixExpressionException("There are too many operators for the operands given.");
            		}
            		// since stack is last in first out, a sequence like 2 1 / will pop 1
            		// first, thus it is important to set the operands in the reverse order
            		tempOperator.setOperand(1, stack.pop());
            		tempOperator.setOperand(0, stack.pop());
            	}
            	stack.push(tempOperator.performOperation());
				break;
			default:
				throw new IllegalPostfixExpressionException("Parser returned an invalid Type: " + type);
			}						
		}		
		if (stack.size() > 1) {
			throw new IllegalPostfixExpressionException("There are too few operators for the operands given.");
		}
		return stack.pop().getValue();
	}
}
