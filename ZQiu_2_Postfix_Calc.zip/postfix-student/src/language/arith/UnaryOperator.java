// added by SQ on 06/03/2018
package language.arith;

import language.*;

public abstract class UnaryOperator<T> implements Operator<T> {
	
	protected Operand<T> op0;
	
	/**
	 * {@inheritDoc}
	 * Unary Operator works with one argument only, so getNumberOfArguments should return 1
	 */
	@Override
	public final int getNumberOfArguments() {
		return 1;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setOperand(int i, Operand<T> operand) {
		if (operand == null) {
			throw new NullPointerException("Could not set null operand.");
		}
		if (i > 0) {
			throw new IllegalArgumentException("Binary operator only accepts operands 0 but received " + i + ".");
		}
		if (op0 != null) {
			throw new IllegalStateException("Position 0 has been previously set.");
		}
		op0 = operand;
	}
}