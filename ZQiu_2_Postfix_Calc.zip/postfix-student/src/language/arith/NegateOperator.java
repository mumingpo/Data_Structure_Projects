// edited by SQ on 06/03/2018
package language.arith;

import language.Operand;
import language.arith.UnaryOperator;

// implemented by SQ on 06/03
/**
 * The {@code NegateOperator} is an operator that performs negation on a single integer
 * @author jcollard
 *
 */
public class NegateOperator extends UnaryOperator<Integer> {
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Operand<Integer> performOperation(){
		if (op0 == null) {
			throw new IllegalStateException("Could not perform operation prior to operands being set.");
		}
		Operand<Integer> temp = new Operand<Integer> (-op0.getValue());
		return temp;
	}
	
	public String toString() {
		return "!";
	}
}