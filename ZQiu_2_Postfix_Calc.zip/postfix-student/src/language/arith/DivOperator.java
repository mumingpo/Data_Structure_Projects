// edited by SQ on 06/03/2018
package language.arith;

import language.BinaryOperator;
import language.Operand;

// implemented by SQ on 06/03
/**
 * The {@link DivOperator} is an operator that performs division on two
 * integers.
 * @author jcollard
 *
 */
public class DivOperator extends BinaryOperator<Integer> {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Operand<Integer> performOperation() {
		if(op0 == null || op1 == null) {
			throw new IllegalStateException("Could not perform operation prior to operands being set.");
		}
		// this should be integer division or something is wrong at other levels
		Operand<Integer> temp = new Operand<Integer> (op0.getValue() / op1.getValue());
		return temp;
	}
	
	public String toString() {
		return "/";
	}
}
